PROJETO: E-COMMERCE BK DOCES
ALUNO: [COLOQUE SEU NOME AQUI]
FACULDADE: Centro Universitário Integrado de Campo Mourão
DATA ENTREGA: [COLOQUE A DATA DE HOJE]

📋 INSTRUÇÕES DE INSTALAÇÃO:

1. BANCO DE DADOS:
   - Importar o arquivo produtos.sql no phpMyAdmin
   - Criar banco com nome: produtos

2. CONFIGURAÇÃO:
   - Colocar os arquivos PHP na pasta htdocs do XAMPP
   - Acessar: http://localhost:8080/TRABALHO.php

3. CREDENCIAIS:
   - MySQL: usuário root, senha vazia
   - Admin: email admin@bkdoces.com, senha admin123

🚀 FUNCIONALIDADES IMPLEMENTADAS:
- Site institucional responsivo
- Sistema de carrinho de compras
- Gerenciamento de produtos
- Cálculo automático de totais

🔗 GITHUB: https://github.com/[SEU-USERNAME]/bk-doces-ecommerce