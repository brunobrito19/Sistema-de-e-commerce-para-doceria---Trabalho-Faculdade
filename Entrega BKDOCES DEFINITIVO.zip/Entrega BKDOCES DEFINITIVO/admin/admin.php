<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BK Doces - Painel Administrativo</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            color: #5A2D2D;
            padding: 20px;
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #FF6B8B;
        }
        
        h1 {
            color: #FF6B8B;
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .admin-panel {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .panel-card {
            background: #FFF5F5;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .panel-card h2 {
            color: #5A2D2D;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #FF6B8B;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        input, textarea, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }
        
        button {
            background: #FF6B8B;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            transition: background 0.3s;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        
        button:hover {
            background: #ff4d73;
        }
        
        .danger {
            background: #ff4757;
        }
        
        .danger:hover {
            background: #ff2e43;
        }
        
        .success {
            background: #2ed573;
        }
        
        .success:hover {
            background: #25b562;
        }
        
        .primary {
            background: #3742fa;
        }
        
        .primary:hover {
            background: #2f36d8;
        }
        
        .products-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .products-table th, .products-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .products-table th {
            background-color: #FF6B8B;
            color: white;
        }
        
        .products-table tr:nth-child(even) {
            background-color: #FFF5F5;
        }
        
        .products-table tr:hover {
            background-color: #ffecef;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            color: white;
            font-weight: bold;
        }
        
        .alert-success {
            background: #2ed573;
        }
        
        .alert-error {
            background: #ff4757;
        }
        
        .alert-info {
            background: #3742fa;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
        
        .action-buttons button {
            padding: 6px 12px;
            font-size: 0.9rem;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-card {
            background: #FFF5F5;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }
        
        .stat-card h3 {
            color: #5A2D2D;
            margin-bottom: 10px;
        }
        
        .stat-card .number {
            font-size: 2rem;
            font-weight: bold;
            color: #FF6B8B;
        }
        
        @media (max-width: 1024px) {
            .admin-panel {
                grid-template-columns: 1fr;
            }
            
            .stats {
                grid-template-columns: 1fr 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .stats {
                grid-template-columns: 1fr;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>BK Doces - Painel Administrativo</h1>
            <p>Gerenciamento de Banco de Dados - Tabela "produtos"</p>
        </header>
        
        <div class="alert alert-info">
            Conectado ao banco de dados com sucesso! 6 produtos encontrados.
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Total de Produtos</h3>
                <div class="number">6</div>
            </div>
            <div class="stat-card">
                <h3>Produtos em Destaque</h3>
                <div class="number">4</div>
            </div>
            <div class="stat-card">
                <h3>Categorias</h3>
                <div class="number">5</div>
            </div>
        </div>
        
        <div class="admin-panel">
            <div class="panel-card">
                <h2>Gerenciar Produtos</h2>
                <div class="form-group">
                    <button class="primary" onclick="showAddForm()">+ Adicionar Novo Produto</button>
                </div>
                
                <div class="form-group">
                    <label for="search-product">Buscar Produto</label>
                    <input type="text" id="search-product" placeholder="Digite o nome do produto">
                </div>
                
                <h3>Operações em Lote</h3>
                <div class="form-group">
                    <button class="danger" onclick="confirmAction('Tem certeza que deseja desativar todos os produtos não destacados?')">Desativar Não Destacados</button>
                </div>
                <div class="form-group">
                    <button class="success" onclick="confirmAction('Tem certeza que deseja atualizar todos os preços?')">Atualizar Preços (+5%)</button>
                </div>
                
                <h3>Exportar/Importar</h3>
                <div class="form-group">
                    <button class="success" onclick="exportData()">Exportar Dados</button>
                    <button class="primary" onclick="showImportSection()">Importar Dados</button>
                </div>
            </div>
            
            <div class="panel-card">
                <h2>Produtos Cadastrados</h2>
                
                <table class="products-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Preço</th>
                            <th>Categoria</th>
                            <th>Destaque</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Trufas e Brownie Tradicionais</td>
                            <td>R$ 5,00</td>
                            <td>trufas</td>
                            <td>Sim</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Bolos Especiais</td>
                            <td>R$ 50,00</td>
                            <td>bolos</td>
                            <td>Sim</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Kit Store special</td>
                            <td>R$ 45,00</td>
                            <td>kits</td>
                            <td>Sim</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Taça Premium</td>
                            <td>R$ 10,00</td>
                            <td>taças</td>
                            <td>Não</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Brigadeiro Gourmet</td>
                            <td>R$ 3,50</td>
                            <td>brigadeiros</td>
                            <td>Sim</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Cupcake Personalizado</td>
                            <td>R$ 8,00</td>
                            <td>cupcakes</td>
                            <td>Não</td>
                            <td class="action-buttons">
                                <button class="success">Editar</button>
                                <button class="danger">Excluir</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <div style="margin-top: 20px; text-align: center;">
                    <button>Anterior</button>
                    <button>1</button>
                    <button>Próximo</button>
                </div>
            </div>
        </div>
        
        <div class="panel-card" id="add-form" style="display: none;">
            <h2>Adicionar Novo Produto</h2>
            <form id="add-product-form">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="product-name">Nome do Produto</label>
                        <input type="text" id="product-name" required>
                    </div>
                    <div class="form-group">
                        <label for="product-price">Preço (R$)</label>
                        <input type="number" id="product-price" step="0.01" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="product-description">Descrição</label>
                    <textarea id="product-description" rows="3" required></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="form-group">
                        <label for="product-category">Categoria</label>
                        <select id="product-category" required>
                            <option value="trufas">Trufas</option>
                            <option value="bolos">Bolos</option>
                            <option value="kits">Kits</option>
                            <option value="taças">Taças</option>
                            <option value="brigadeiros">Brigadeiros</option>
                            <option value="cupcakes">Cupcakes</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="product-image">URL da Imagem</label>
                        <input type="url" id="product-image" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>
                        <input type="checkbox" id="product-featured"> Produto em Destaque
                    </label>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="success">Adicionar Produto</button>
                    <button type="button" class="danger" onclick="hideAddForm()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Funções para simular operações no banco de dados
        function confirmAction(message) {
            if (confirm(message)) {
                showAlert('Operação realizada com sucesso!', 'success');
            }
        }
        
        function exportData() {
            showAlert('Dados exportados com sucesso!', 'success');
        }
        
        function showAddForm() {
            document.getElementById('add-form').style.display = 'block';
        }
        
        function hideAddForm() {
            document.getElementById('add-form').style.display = 'none';
        }
        
        function showImportSection() {
            alert('Funcionalidade de importação será implementada aqui.');
        }
        
        function showAlert(message, type) {
            // Esta função seria implementada para mostrar alertas na interface
            alert(message);
        }
        
        // Simular envio do formulário
        document.getElementById('add-product-form').addEventListener('submit', function(e) {
            e.preventDefault();
            showAlert('Produto adicionado com sucesso!', 'success');
            this.reset();
            hideAddForm();
        });
        
        // Simular exclusão de produto
        document.querySelectorAll('.action-buttons .danger').forEach(button => {
            button.addEventListener('click', function() {
                if (confirm('Tem certeza que deseja excluir este produto?')) {
                    const row = this.closest('tr');
                    row.style.backgroundColor = '#ffcccc';
                    showAlert('Produto excluído com sucesso!', 'success');
                }
            });
        });
        
        // Simular edição de produto
        document.querySelectorAll('.action-buttons .success').forEach(button => {
            button.addEventListener('click', function() {
                alert('Editor de produto será aberto aqui.');
            });
        });
    </script>
</body>
</html>