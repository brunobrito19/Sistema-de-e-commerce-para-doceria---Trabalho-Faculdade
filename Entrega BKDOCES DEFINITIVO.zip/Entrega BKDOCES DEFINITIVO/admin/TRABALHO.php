<?php

$hostname = "localhost";
$bancodedados = "produtos";
$usuario = "root";
$senha = "";

//Conectar ao banco de dados
$mysqli = new mysqli ($hostname, $usuario, $senha, $bancodedados); 

if ($mysqli->connect_errno) {
    echo "falha ao conectar:(" .$mysqli->connect_errno .")" . $mysqli->connect_errno;

}
else 

    echo "Conectado ao banco de dados";


// Configurações iniciais
$tituloPagina = "BK Doces - Bombons e Trufas Artesanais Premium";
$paginaAtual = isset($_GET['pagina']) ? $_GET['pagina'] : 'home';

// Buscar produtos no banco de dados
$produtos = [];
$result = $mysqli->query("Select * FROM produtos WHERE destaque = TRUE");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        // Formatar o preço para exibição
        $row['preco'] = number_format($row['preco'], 2, ',', '.');
        $produtos[] = $row;
}
$result->free();

}

// Buscar contatos no banco de dados

$contatos = [];
$result = $mysqli->query("SELECT * from contatos");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $contatos[] = $row;
    }
    $result->free();
}

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloPagina; ?></title>
    <style>
        /* Estilos Gerais */
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #FFF5F5;
            font-family: 'Quicksand', sans-serif;
            color: #5A2D2D;
            overflow-x: hidden;
        }
        
        /* Header */
        header {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            padding: 20px 0;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .logo h1 {
            font-family: 'Pacifico', cursive;
            color: white;
            font-size: 2.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        nav {
            display: flex;
            align-items: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        
        .nav-links a:hover {
            background-color: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }
        
        .search-bar {
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            padding: 10px 15px;
            border: none;
            border-radius: 25px;
            outline: none;
            width: 200px;
        }
        
        .search-bar button {
            padding: 10px 20px;
            background-color: #5A2D2D;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .search-bar button:hover {
            background-color: #7A3D3D;
        }
        
        /* Main Content */
        main {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            min-height: 70vh;
        }
        
        .section {
            display: none;
            padding: 40px 0;
        }
        
        .section.active {
            display: block;
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        h2 {
            font-family: 'Pacifico', cursive;
            color: #FF6B8B;
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 20px;
        }
        
        p {
            line-height: 1.6;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        
        .candy-decoration {
            text-align: center;
            font-size: 2rem;
            margin: 30px 0;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
        }
        
        .product-image {
            height: 200px;
            background-size: cover;
            background-position: center;
        }
        
        .product-info {
            padding: 20px;
        }
        
        .product-info h3 {
            color: #5A2D2D;
            margin-bottom: 10px;
        }
        
        .price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #FF6B8B;
            margin-top: 15px;
        }
        
        /* Contact Info */
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        
        .contact-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .contact-card h3 {
            color: #FF6B8B;
            margin-bottom: 15px;
        }
        
        /* Floating Candies */
        .floating-candies {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }
        
        .candy {
            position: absolute;
            font-size: 2rem;
            opacity: 0.3;
            animation: float linear infinite;
        }
        
        @keyframes float {
            from { transform: translateY(100vh) rotate(0deg); }
            to { transform: translateY(-100px) rotate(360deg); }
        }
        
        /* Footer */
        footer {
            background: linear-gradient(135deg, #5A2D2D 0%, #7A3D3D 100%);
            color: white;
            text-align: center;
            padding: 30px 20px;
            margin-top: 60px;
        }
        
        .candy-icon {
            font-size: 1.5rem;
            animation: spin 3s infinite;
        }
        
        @keyframes spin {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(20deg); }
        }
        
        /* Responsividade */
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                justify-content: center;
            }
            
            .search-bar {
                width: 100%;
                justify-content: center;
            }
            
            .search-bar input {
                width: 100%;
            }
            
            h2 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Efeito de doces flutuantes -->
    <div class="floating-candies" id="floating-candies"></div>
    
    <header>
        <div class="header-container">
            <div class="logo">
                <h1>BK Doces</h1>
            </div>
            <nav>
                <div class="nav-links">
                    <a href="?pagina=home" class="<?php echo $paginaAtual == 'home' ? 'active' : ''; ?>">Home</a>
                    <a href="?pagina=quem-somos" class="<?php echo $paginaAtual == 'quem-somos' ? 'active' : ''; ?>">Quem Somos</a>
                    <a href="?pagina=produtos" class="<?php echo $paginaAtual == 'produtos' ? 'active' : ''; ?>">Produtos</a>
                    <a href="?pagina=contato" class="<?php echo $paginaAtual == 'contato' ? 'active' : ''; ?>">Contato</a>
                    <a href="?pagina=localizacao" class="<?php echo $paginaAtual == 'localizacao' ? 'active' : ''; ?>">Localização</a>
                </div>
                <div class="search-bar">
                    <input type="text" placeholder="Pesquisar doces...">
                    <button>Buscar</button>
                </div>
            </nav>
        </div>
    </header>
    
    <main>
        <!-- Seção Home -->
        <section id="home" class="section <?php echo ($paginaAtual == 'home') ? 'active' : ''; ?>">
            <h2>Bem-vindo à BK Doces!</h2>
            <div class="candy-decoration">🍫 🍬 🧁 🎂 🍩 🍭</div>
            <p>Os melhores bombons e trufas artesanais da região, feitos com amor e ingredientes de alta qualidade para adoçar sua vida!</p>
            
            <div style="text-align: center; margin: 40px 0;">
                <img src="https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                     alt="Bombons artesanais" 
                     style="max-width: 100%; border-radius: 15px; box-shadow: 0 15px 30px rgba(255, 107, 139, 0.2); border: 5px solid white;">
            </div>
            
            <p>Nossos doces são produzidos artesanalmente, com receitas exclusivas e muito carinho. Cada mordida é uma experiência única de sabores e texturas que vão te surpreender!</p>
            
            <div class="candy-decoration">🍫 🍬 🧁 🎂 🍩 🍭</div>
        </section>
        
        <!-- Seção Quem Somos -->
        <section id="quem-somos" class="section <?php echo ($paginaAtual == 'quem-somos') ? 'active' : ''; ?>">
            <h2>Nossa Doce História</h2>
            <div class="candy-decoration">❤️ 🧡 💛 💚 💙 💜</div>
            
            <div style="display: flex; flex-wrap: wrap; gap: 30px; align-items: center; margin-bottom: 30px;">
                <div style="flex: 1; min-width: 300px;">
                    <img src="https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" 
                         alt="Equipe BK Doces" 
                         style="width: 100%; border-radius: 15px; box-shadow: 0 10px 20px rgba(0,0,0,0.1);">
                </div>
                <div style="flex: 1; min-width: 300px;">
                    <p>A BK Doces nasceu em 2024 do amor por doces e da vontade de trazer sabores especiais para Campo Mourão. Tudo começou quando Kailayne e Bruno, apaixonados por chocolate, começaram a fazer trufas para presentear amigos e familiares.</p>
                    
                    <p>O feedback foi tão positivo que resolveram transformar o hobby em negócio. Começamos pequeno, produzindo em casa e vendendo para conhecidos. Com o tempo, a qualidade de nossos produtos falou por si e a demanda cresceu.</p>
                    
                    <p>Hoje, com muito orgulho, produzimos mais de 20 variedades de bombons e trufas, e incluimos em nossa produção bolos e bombons na taça, sempre mantendo a qualidade artesanal e o cuidado com cada detalhe que nos tornou conhecidos. Nosso segredo? Ingredientes selecionados, receitas exclusivas e muito carinho em cada produção!</p>
                </div>
            </div>
        </section>
        
        <!-- Seção Produtos -->
        <section id="produtos" class="section <?php echo ($paginaAtual == 'produtos') ? 'active' : ''; ?>">
            <h2>Nossas Delícias</h2>
            <p>Conheça nossa linha premium de produtos artesanais, cada um feito com ingredientes selecionados e muito amor:</p>
            
            <div class="product-grid">
                <?php foreach ($produtos as $produto): ?>
                <div class="product-card">
                    <div class="product-image" 
                         style="background-image: url('<?php echo $produto['imagem']; ?>');">
                    </div>
                    <div class="product-info">
                        <h3><?php echo $produto['nome']; ?></h3>
                        <p><?php echo $produto['descricao']; ?></p>
                        <div class="price">R$ <?php echo $produto['preco']; ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="candy-decoration">🍫 🍬 🧁 🎂 🍩 🍭</div>
        </section>
        
        <!-- Seção Contato -->
        <section id="contato" class="section <?php echo ($paginaAtual == 'contato') ? 'active' : ''; ?>">
            <h2>Fale Conosco</h2>
            <p>Estamos sempre prontos para atender você! Entre em contato por qualquer um dos canais abaixo:</p>
            
            <div class="contact-info">
                <?php foreach ($contatos as $contato): ?>
                <div class="contact-card">
                    <h3><?php echo $contato['nome']; ?></h3>
                    <p><strong>Telefone:</strong> <?php echo $contato['telefone']; ?></p>
                    <p><strong>Email:</strong> <?php echo $contato['email']; ?></p>
                    <p><strong>Horário:</strong> <?php echo $contato['horario']; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div style="margin-top: 50px; text-align: center;">
                <p>Siga-nos nas redes sociais e fique por dentro das novidades!</p>
                <div class="candy-decoration">📱 💻 🖥️ 📲</div>
                <p style="font-size: 1.2rem; margin-top: 10px;">@bkdocesoficial</p>
            </div>
        </section>
        
        <!-- Seção Localização -->
        <section id="localizacao" class="section <?php echo ($paginaAtual == 'localizacao') ? 'active' : ''; ?>">
            <h2>Onde Estamos</h2>
            <div class="candy-decoration">📍 🗺️ 🚗 🚕</div>
            
            <p>Nosso encantador espaço está localizado no coração de Campo Mourão - PR, pronto para te receber com todo o carinho e os melhores doces da região!</p>
            
            <div style="margin: 30px 0; text-align: center;">
                <!-- Mapa pode ser inserido aqui -->
                <div style="background-color: #f8f8f8; padding: 40px; border-radius: 15px;">
                    <p style="font-size: 1.2rem; color: #FF6B8B;">📍 Mapa interativo aqui</p>
                    <p>(Integre com Google Maps ou OpenStreetMap)</p>
                </div>
            </div>
            
            <div style="background-color: #FFF5F5; padding: 20px; border-radius: 15px; text-align: center; max-width: 600px; margin: 0 auto;">
                <p><strong>Endereço:</strong> Av. Armelindo Trombini - Jardim Flora II, Campo Mourão - PR</p>
                <p><strong>Horário de atendimento:</strong> Segunda a Sábado, das 9h às 18h</p>
            </div>
            
            <div class="candy-decoration">🍫 🍬 🧁 🎂 🍩 🍭</div>
        </section>
    </main>
    
    <footer>
        <p><span class="candy-icon">🍫</span> © <?php echo date('Y'); ?> BK Doces - Doces Artesanais <span class="candy-icon">🍬</span></p>
        <p>Campo Mourão - PR | Feito com amor e muito chocolate!</p>
    </footer>

    <script>
        // Função para mostrar a seção clicada
        function showSection(sectionId) {
            // Esconde todas as seções
            document.querySelectorAll('.section').forEach(section => {
                section.classList.remove('active');
            });
            
            // Mostra a seção selecionada
            document.getElementById(sectionId).classList.add('active');
            
            // Rola suavemente para a seção
            document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        
        // Cria doces flutuantes
        function createFloatingCandies() {
            const candies = ['🍫', '🍬', '🧁', '🍩', '🍭', '🎂', '🍪', '🍮'];
            const container = document.getElementById('floating-candies');
            
            for (let i = 0; i < 20; i++) {
                const candy = document.createElement('div');
                candy.className = 'candy';
                candy.textContent = candies[Math.floor(Math.random() * candies.length)];
                candy.style.left = `${Math.random() * 100}%`;
                candy.style.top = `${Math.random() * 100}%`;
                candy.style.animationDuration = `${15 + Math.random() * 20}s`;
                candy.style.animationDelay = `${Math.random() * 5}s`;
                container.appendChild(candy);
            }
        }
        
        // Inicializa quando a página carrega
        window.addEventListener('DOMContentLoaded', function() {
            createFloatingCandies();
            
            // Rolagem suave para o topo ao carregar
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    </script>
</body>
</html>