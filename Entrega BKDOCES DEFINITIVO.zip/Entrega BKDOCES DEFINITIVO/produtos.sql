-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 01/12/2025 às 21:43
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `produtos`
--

DELIMITER $$
--
-- Procedimentos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `inserir_pedidos_teste` (`quantidade` INT)   BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE cliente_id INT;
    DECLARE pedido_id INT;
    
    WHILE i <= quantidade DO
        -- Selecionar cliente aleatório
        SET cliente_id = (SELECT id FROM usuarios ORDER BY RAND() LIMIT 1);
        
        -- Inserir pedido
        INSERT INTO pedidos (cliente_nome, cliente_telefone, total, status)
        VALUES (
            CONCAT('Cliente Teste ', i),
            CONCAT('(44) 9', LPAD(FLOOR(RAND() * 9000) + 1000, 4, '0'), '-', LPAD(FLOOR(RAND() * 9000) + 1000, 4, '0')),
            ROUND(RAND() * 200 + 20, 2),
            ELT(FLOOR(RAND() * 4) + 1, 'recebido', 'preparacao', 'pronto', 'entregue')
        );
        
        SET i = i + 1;
    END WHILE;
    
    SELECT CONCAT('Inseridos ', quantidade, ' pedidos de teste') as resultado;
END$$

--
-- Funções
--
CREATE DEFINER=`root`@`localhost` FUNCTION `verificar_estoque` (`pedido_id` INT) RETURNS VARCHAR(200) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE msg VARCHAR(200) DEFAULT 'OK';
    DECLARE done INT DEFAULT FALSE;
    DECLARE prod_nome VARCHAR(100);
    DECLARE prod_estoque INT;
    DECLARE qtd_pedido INT;
    
    -- Cursor para verificar cada item
    DECLARE cur CURSOR FOR 
        SELECT p.nome, p.estoque, pi.quantidade 
        FROM pedido_itens pi
        JOIN produtos p ON pi.produto_id = p.id
        WHERE pi.pedido_id = pedido_id;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO prod_nome, prod_estoque, qtd_pedido;
        IF done THEN LEAVE read_loop; END IF;
        
        IF prod_estoque < qtd_pedido THEN
            SET msg = CONCAT('Estoque insuficiente: ', prod_nome, 
                           ' (Estoque: ', prod_estoque, 
                           ', Necessário: ', qtd_pedido, ')');
            LEAVE read_loop;
        END IF;
    END LOOP;
    
    CLOSE cur;
    RETURN msg;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `auditoria_precos`
--

CREATE TABLE `auditoria_precos` (
  `id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `preco_antigo` decimal(10,2) DEFAULT NULL,
  `preco_novo` decimal(10,2) DEFAULT NULL,
  `data_alteracao` timestamp NOT NULL DEFAULT current_timestamp(),
  `usuario` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `contatos`
--

CREATE TABLE `contatos` (
  `id` int(6) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `telefone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `horario` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `contatos`
--

INSERT INTO `contatos` (`id`, `nome`, `telefone`, `email`, `horario`, `created_at`) VALUES
(1, 'Kailayne', '(44) 97400-2656', 'kailayne@bkdoces.com', '9h às 18h', '2025-09-17 19:30:46'),
(2, 'Bruno', '(44) 99726-9992', 'bruno@bkdoces.com', '9h às 18h', '2025-09-17 19:30:46');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(6) UNSIGNED NOT NULL,
  `cliente_nome` varchar(100) NOT NULL,
  `cliente_telefone` varchar(20) NOT NULL,
  `cliente_email` varchar(100) DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `status` enum('recebido','preparacao','pronto','entregue') DEFAULT 'recebido',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`id`, `cliente_nome`, `cliente_telefone`, `cliente_email`, `total`, `status`, `created_at`) VALUES
(1, 'João Silva', '(44) 99999-8888', NULL, 85.50, 'entregue', '2025-12-01 20:24:09'),
(2, 'Maria Santos', '(44) 98888-7777', NULL, 120.00, 'preparacao', '2025-12-01 20:24:09'),
(3, 'Pedro Oliveira', '(44) 97777-6666', NULL, 45.00, 'recebido', '2025-12-01 20:24:09'),
(4, 'Ana Costa', '(44) 96666-5555', NULL, 200.00, 'entregue', '2025-12-01 20:24:09');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedido_itens`
--

CREATE TABLE `pedido_itens` (
  `id` int(6) UNSIGNED NOT NULL,
  `pedido_id` int(6) UNSIGNED NOT NULL,
  `produto_id` int(6) UNSIGNED NOT NULL,
  `quantidade` int(6) NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(6) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `descricao` text NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `imagem` varchar(255) NOT NULL,
  `destaque` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `estoque` int(11) DEFAULT 10,
  `estoque_minimo` int(11) DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `descricao`, `preco`, `categoria`, `imagem`, `destaque`, `created_at`, `estoque`, `estoque_minimo`) VALUES
(1, 'Trufas e Brownie Tradicionais', 'Deliciosas trufas de chocolate ao leite, meio amargo e branco, com acabamento perfeito.', 5.00, 'trufas', 'https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 1, '2025-09-17 19:30:45', 10, 5),
(2, 'Bolos Especiais', 'Bolos recheados com sabores exclusivos como maracujá, supresinha de morango e muito mais.', 50.00, 'bolos', 'https://images.unsplash.com/photo-1602351447937-745cb720612f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 1, '2025-09-17 19:30:45', 10, 5),
(3, 'Kit Store special', 'Caixas personalizadas com seleção dos melhores bombons, trufas ou bolos perfeito para presentear.', 45.00, 'kits', 'https://images.unsplash.com/photo-1604066867775-43f48e3957d8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 1, '2025-09-17 19:30:45', 10, 5),
(4, 'Taça Premium', 'Edição especial com ingredientes selecionados e combinações sofisticadas.', 10.00, 'taças', 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 0, '2025-09-17 19:30:45', 10, 5),
(5, 'Brigadeiro Gourmet', 'Brigadeiros especiais com sabores exclusivos e ingredientes premium.', 3.50, 'brigadeiros', 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 1, '2025-09-17 19:30:45', 10, 5),
(6, 'Cupcake Personalizado', 'Cupcakes decorados com temas especiais para festas e eventos.', 8.00, 'cupcakes', 'https://images.unsplash.com/photo-1614707267537-b85aaf00c4b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80', 0, '2025-09-17 19:30:45', 10, 5);

--
-- Acionadores `produtos`
--
DELIMITER $$
CREATE TRIGGER `tr_auditoria_preco` AFTER UPDATE ON `produtos` FOR EACH ROW BEGIN
    IF OLD.preco != NEW.preco THEN
        INSERT INTO auditoria_precos (produto_id, preco_antigo, preco_novo, usuario)
        VALUES (OLD.id, OLD.preco, NEW.preco, USER());
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(6) UNSIGNED NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('admin','cliente') DEFAULT 'cliente',
  `data_cadastro` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `tipo`, `data_cadastro`) VALUES
(1, 'Administrador', 'admin@bkdoces.com', '0192023a7bbd73250516f069df18b500', 'admin', '2025-11-10 19:19:39');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `auditoria_precos`
--
ALTER TABLE `auditoria_precos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_produto` (`produto_id`),
  ADD KEY `idx_data` (`data_alteracao`);

--
-- Índices de tabela `contatos`
--
ALTER TABLE `contatos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pedidos_data` (`created_at`),
  ADD KEY `idx_pedidos_status` (`status`);

--
-- Índices de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_produtos_categoria` (`categoria`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auditoria_precos`
--
ALTER TABLE `auditoria_precos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `contatos`
--
ALTER TABLE `contatos`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `pedido_itens`
--
ALTER TABLE `pedido_itens`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `pedido_itens`
--
ALTER TABLE `pedido_itens`
  ADD CONSTRAINT `pedido_itens_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `pedido_itens_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
