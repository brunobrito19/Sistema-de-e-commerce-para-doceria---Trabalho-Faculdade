<?php
// app/controllers/HomeController.php
class HomeController {
    
        // Página inicial
    public function index() {
        // Conectar ao banco de dados
        $db = Database::getInstance();
        
        // Debug: Verificar conexão
        if ($db->connect_error) {
            die("Erro de conexão: " . $db->connect_error);
        }
        
        // Buscar produtos em destaque - USAR 1 em vez de TRUE
        $sql = "SELECT * FROM produtos WHERE destaque = 1 ORDER BY id DESC LIMIT 4";
        $result = $db->query($sql);
        
        // Debug da query
        if (!$result) {
            $produtos = [];
            $erro = "Erro na query: " . $db->error . "<br>SQL: " . $sql;
        } else {
            $produtos = [];
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    // Formatar preço para exibição
                    $row['preco_formatado'] = number_format($row['preco'], 2, ',', '.');
                    $produtos[] = $row;
                }
            } else {
                $erro = "Nenhum produto encontrado na tabela 'produtos' com destaque = 1";
            }
        }
        
        // Dados para a view
        $dados = [
            'titulo' => 'BK Doces - Doces Artesanais Premium',
            'produtos' => $produtos,
            'mensagem' => $_SESSION['mensagem'] ?? null,
            'erro' => $erro ?? null
        ];
        
        // Limpar mensagem da sessão
        if (isset($_SESSION['mensagem'])) {
            unset($_SESSION['mensagem']);
        }
        
        // Carregar a view
        $this->view('home', $dados);
    }
    
    // Página de produtos
    public function produtos() {
        $db = Database::getInstance();
        
        $sql = "SELECT * FROM produtos ORDER BY nome";
        $result = $db->query($sql);
        
        $produtos = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $row['preco_formatado'] = number_format($row['preco'], 2, ',', '.');
                $produtos[] = $row;
            }
        }
        
        $dados = [
            'titulo' => 'Nossos Produtos - BK Doces',
            'produtos' => $produtos
        ];
        
        $this->view('produtos', $dados);
    }
    
    // Página sobre
    public function sobre() {
        $dados = [
            'titulo' => 'Sobre a BK Doces'
        ];
        
        $this->view('sobre', $dados);
    }
    
    // Página contato
    public function contato() {
        $dados = [
            'titulo' => 'Fale Conosco - BK Doces'
        ];
        
        $this->view('contato', $dados);
    }
    
    // Método para carregar views
    private function view($viewName, $dados = []) {
        // Extrair variáveis para a view
        extract($dados);
        
        // Caminho da view
        $viewFile = APP_PATH . "/views/{$viewName}.php";
        
        // Verificar se a view existe
        if (!file_exists($viewFile)) {
            die("View '{$viewName}' não encontrada!");
        }
        
        // Incluir a view
        require_once $viewFile;
    }
}
?>