<?php
// app/controllers/AuthController.php
class AuthController {
    
    // Página de login
    public function login() {
        // Se já está logado, redireciona
        if (isset($_SESSION['usuario'])) {
            header('Location: ' . BASE_URL);
            exit();
        }
        
        $erro = null;
        
        // Processar formulário de login
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
            $email = trim($_POST['email']);
            $senha = trim($_POST['senha']);
            
            if (empty($email) || empty($senha)) {
                $erro = "Preencha todos os campos!";
            } else {
                $db = Database::getInstance();
                
                // Buscar usuário no banco (senha MD5)
                $sql = "SELECT * FROM usuarios WHERE email = ? AND senha = MD5(?)";
                $stmt = $db->prepare($sql);
                $stmt->bind_param("ss", $email, $senha);
                $stmt->execute();
                
                $result = $stmt->get_result();
                $usuario = $result->fetch_assoc();
                
                if ($usuario) {
                    // Login bem-sucedido
                    $_SESSION['usuario'] = [
                        'id' => $usuario['id'],
                        'nome' => $usuario['nome'],
                        'email' => $usuario['email'],
                        'tipo' => $usuario['tipo']
                    ];
                    
                    $_SESSION['mensagem'] = "✅ Login realizado com sucesso!";
                    header('Location: ' . BASE_URL . '?controller=home&action=index');
                    exit();
                } else {
                    $erro = "❌ E-mail ou senha incorretos!";
                }
            }
        }
        
        // Dados para a view
        $dados = [
            'titulo' => 'Login - BK Doces',
            'erro' => $erro
        ];
        
        $this->view('auth/login', $dados);
    }
    
    // Página de cadastro
    public function register() {
        // Se já está logado, redireciona
        if (isset($_SESSION['usuario'])) {
            header('Location: ' . BASE_URL);
            exit();
        }
        
        $erro = null;
        $sucesso = null;
        
        // Processar formulário de cadastro
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
            $nome = trim($_POST['nome']);
            $email = trim($_POST['email']);
            $senha = trim($_POST['senha']);
            $confirmar_senha = trim($_POST['confirmar_senha']);
            
            // Validações
            if (empty($nome) || empty($email) || empty($senha)) {
                $erro = "Preencha todos os campos!";
            } elseif ($senha !== $confirmar_senha) {
                $erro = "As senhas não coincidem!";
            } elseif (strlen($senha) < 6) {
                $erro = "A senha deve ter pelo menos 6 caracteres!";
            } else {
                $db = Database::getInstance();
                
                // Verificar se email já existe
                $sql_check = "SELECT id FROM usuarios WHERE email = ?";
                $stmt_check = $db->prepare($sql_check);
                $stmt_check->bind_param("s", $email);
                $stmt_check->execute();
                
                if ($stmt_check->get_result()->num_rows > 0) {
                    $erro = "Este e-mail já está cadastrado!";
                } else {
                    // Inserir novo usuário
                    $sql_insert = "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, MD5(?), 'cliente')";
                    $stmt_insert = $db->prepare($sql_insert);
                    $stmt_insert->bind_param("sss", $nome, $email, $senha);
                    
                    if ($stmt_insert->execute()) {
                        $sucesso = "✅ Cadastro realizado com sucesso! Faça login.";
                    } else {
                        $erro = "❌ Erro ao cadastrar: " . $db->error;
                    }
                }
            }
        }
        
        // Dados para a view
        $dados = [
            'titulo' => 'Cadastro - BK Doces',
            'erro' => $erro,
            'sucesso' => $sucesso
        ];
        
        $this->view('auth/register', $dados);
    }
    
    // Logout
    public function logout() {
        session_destroy();
        $_SESSION['mensagem'] = "👋 Até logo! Você saiu do sistema.";
        header('Location: ' . BASE_URL);
        exit();
    }
    
    // Método para carregar views
    private function view($viewName, $dados = []) {
        extract($dados);
        
        // Caminho da view
        $viewFile = APP_PATH . "/views/{$viewName}.php";
        
        // Verificar se a view existe
        if (!file_exists($viewFile)) {
            die("View '{$viewName}' não encontrada!");
        }
        
        // Incluir a view
        require_once $viewFile;
    }
}
?>