<?php
// app/controllers/AdminController.php

class AdminController {
    private $db;
    
    public function __construct() {
        // NÃO iniciar sessão aqui - já foi iniciada no index.php
        // session_start(); // REMOVER ESTA LINHA
        
        // Verificar se usuário está logado e é admin
        $this->checkAdminAccess();
        
        // Conectar ao banco
        $this->connectDB();
    }
    
    private function checkAdminAccess() {
        if (!isset($_SESSION['usuario'])) {
            header('Location: /bkdoces-mvc/public/?controller=auth&action=login');
            exit();
        }
        
        if ($_SESSION['usuario']['tipo'] !== 'admin') {
            echo "<h2>⛔ Acesso Restrito</h2>";
            echo "<p>Apenas administradores podem acessar esta página.</p>";
            echo '<p><a href="/bkdoces-mvc/public/">Voltar para Home</a></p>';
            exit();
        }
    }
    
    private function connectDB() {
        // Conexão direta
        $this->db = new mysqli('localhost', 'root', '', 'produtos');
        
        if ($this->db->connect_error) {
            die("Erro na conexão com o banco: " . $this->db->connect_error);
        }
    }
    
    // Dashboard principal
    public function dashboard() {
        // Buscar dados do banco (com tratamento de erro)
        try {
            $dados = [
                'titulo' => 'Dashboard Administrativo - BK Doces',
                'estatisticas' => $this->getEstatisticas(),
                'ultimosPedidos' => $this->getUltimosPedidos(),
                'produtosMaisVendidos' => $this->getProdutosMaisVendidos(),
                'vendasMensais' => $this->getVendasMensais(),
                'statusPedidos' => $this->getStatusPedidos(),
                'vendasHoje' => $this->getVendasHoje(),
                'usuario' => $_SESSION['usuario']
            ];
        } catch (Exception $e) {
            // Em caso de erro, mostrar dados de teste
            $dados = $this->getDadosTeste();
        }
        
        // Carregar view
        $this->view('admin/dashboard', $dados);
    }
    
    private function getEstatisticas() {
        $hoje = date('Y-m-d');
        $mesAtual = date('Y-m');
        
        // 1. Vendas do mês atual (com tratamento de erro)
        $sql = "SELECT COALESCE(SUM(total), 0) as total FROM pedidos 
                WHERE DATE_FORMAT(created_at, '%Y-%m') = '$mesAtual' 
                AND status = 'entregue'";
        $result = $this->db->query($sql);
        $vendasMes = $result ? $result->fetch_assoc()['total'] : 0;
        
        // 2. Pedidos de hoje
        $sql = "SELECT COUNT(*) as total FROM pedidos 
                WHERE DATE(created_at) = '$hoje'";
        $result = $this->db->query($sql);
        $pedidosHoje = $result ? $result->fetch_assoc()['total'] : 0;
        
        // 3. Ticket médio
        $sql = "SELECT COALESCE(AVG(total), 0) as ticket_medio 
                FROM pedidos 
                WHERE status = 'entregue' 
                AND DATE_FORMAT(created_at, '%Y-%m') = '$mesAtual'";
        $result = $this->db->query($sql);
        $ticketMedio = $result ? $result->fetch_assoc()['ticket_medio'] : 0;
        
        // 4. Total de clientes
        $sql = "SELECT COUNT(DISTINCT cliente_email) as total FROM pedidos 
                WHERE cliente_email IS NOT NULL AND cliente_email != ''";
        $result = $this->db->query($sql);
        $clientes = $result ? $result->fetch_assoc()['total'] : 0;
        
        // 5. Pedidos pendentes
        $sql = "SELECT COUNT(*) as total FROM pedidos 
                WHERE status = 'recebido' OR status = 'preparacao'";
        $result = $this->db->query($sql);
        $pendentes = $result ? $result->fetch_assoc()['total'] : 0;
        
        // 6. Produtos em estoque baixo - VERIFICAR SE A COLUNA EXISTE
        $estoqueBaixo = 0;
        try {
            // Verificar se coluna 'estoque' existe
            $sql_check = "SHOW COLUMNS FROM produtos LIKE 'estoque'";
            $check_result = $this->db->query($sql_check);
            
            if ($check_result && $check_result->num_rows > 0) {
                // Coluna existe, fazer consulta
                $sql = "SELECT COUNT(*) as total FROM produtos 
                        WHERE estoque <= IFNULL(estoque_minimo, 5)";
                $result = $this->db->query($sql);
                $estoqueBaixo = $result ? $result->fetch_assoc()['total'] : 0;
            }
        } catch (Exception $e) {
            // Ignorar erro - estoque baixo será 0
            $estoqueBaixo = 0;
        }
        
        // Mês em português
        $meses = [
            'January' => 'Janeiro', 'February' => 'Fevereiro', 'March' => 'Março',
            'April' => 'Abril', 'May' => 'Maio', 'June' => 'Junho',
            'July' => 'Julho', 'August' => 'Agosto', 'September' => 'Setembro',
            'October' => 'Outubro', 'November' => 'Novembro', 'December' => 'Dezembro'
        ];
        $mesPortugues = $meses[date('F')] ?? date('F');
        
        return [
            'vendas_mes' => number_format($vendasMes, 2, ',', '.'),
            'vendas_mes_raw' => $vendasMes,
            'pedidos_hoje' => $pedidosHoje,
            'ticket_medio' => number_format($ticketMedio, 2, ',', '.'),
            'clientes' => $clientes,
            'pendentes' => $pendentes,
            'estoque_baixo' => $estoqueBaixo,
            'mes_atual' => $mesPortugues . ' ' . date('Y')
        ];
    }
    
    private function getUltimosPedidos($limit = 8) {
        $sql = "SELECT * FROM pedidos 
                ORDER BY created_at DESC 
                LIMIT $limit";
        $result = $this->db->query($sql);
        
        $pedidos = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                // Formatar dados
                $row['total_formatado'] = number_format($row['total'], 2, ',', '.');
                $row['data_formatada'] = date('d/m H:i', strtotime($row['created_at']));
                
                // Nome curto do cliente
                $row['cliente_curto'] = explode(' ', $row['cliente_nome'])[0];
                if (strlen($row['cliente_curto']) > 10) {
                    $row['cliente_curto'] = substr($row['cliente_curto'], 0, 10) . '...';
                }
                
                $pedidos[] = $row;
            }
        }
        
        return $pedidos;
    }
    
    private function getProdutosMaisVendidos() {
        // Se não tiver tabela pedido_itens, retorna array vazio
        $produtos = [];
        
        try {
            // Verificar se tabela pedido_itens existe
            $sql_check = "SHOW TABLES LIKE 'pedido_itens'";
            $check_result = $this->db->query($sql_check);
            
            if ($check_result && $check_result->num_rows > 0) {
                // Consulta real para produtos mais vendidos
                $sql = "SELECT 
                        p.nome,
                        SUM(pi.quantidade) as total_vendido,
                        p.estoque
                        FROM pedido_itens pi
                        JOIN produtos p ON pi.produto_id = p.id
                        JOIN pedidos pd ON pi.pedido_id = pd.id
                        WHERE pd.status = 'entregue'
                        GROUP BY p.id
                        ORDER BY total_vendido DESC
                        LIMIT 5";
                
                $result = $this->db->query($sql);
                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        $produtos[] = $row;
                    }
                }
            }
        } catch (Exception $e) {
            // Ignorar erro
        }
        
        // Se não encontrou produtos, usar dados de exemplo
        if (empty($produtos)) {
            $produtos = [
                ['nome' => 'Trufas Artesanais', 'total_vendido' => 42, 'estoque' => 15],
                ['nome' => 'Bolos Especiais', 'total_vendido' => 28, 'estoque' => 8],
                ['nome' => 'Kit Presente', 'total_vendido' => 35, 'estoque' => 12]
            ];
        }
        
        return $produtos;
    }
    
    private function getVendasMensais($meses = 6) {
        $vendas = [
            'meses' => [],
            'quantidades' => [],
            'valores' => []
        ];
        
        try {
            $sql = "SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') as mes,
                    COUNT(*) as quantidade_pedidos,
                    COALESCE(SUM(total), 0) as valor_total
                    FROM pedidos
                    WHERE created_at >= DATE_SUB(NOW(), INTERVAL $meses MONTH)
                    AND status = 'entregue'
                    GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                    ORDER BY mes";
            
            $result = $this->db->query($sql);
            
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    // Formatar mês (ex: Nov/24)
                    $data = strtotime($row['mes'] . '-01');
                    $mesAbreviado = date('M', $data);
                    $ano = date('y', $data);
                    
                    // Traduzir mês para português
                    $mesesAbrev = [
                        'Jan' => 'Jan', 'Feb' => 'Fev', 'Mar' => 'Mar', 'Apr' => 'Abr',
                        'May' => 'Mai', 'Jun' => 'Jun', 'Jul' => 'Jul', 'Aug' => 'Ago',
                        'Sep' => 'Set', 'Oct' => 'Out', 'Nov' => 'Nov', 'Dec' => 'Dez'
                    ];
                    
                    $vendas['meses'][] = ($mesesAbrev[$mesAbreviado] ?? $mesAbreviado) . '/' . $ano;
                    $vendas['quantidades'][] = (int)$row['quantidade_pedidos'];
                    $vendas['valores'][] = (float)$row['valor_total'];
                }
            }
        } catch (Exception $e) {
            // Dados de exemplo em caso de erro
            $vendas = [
                'meses' => ['Jun/24', 'Jul/24', 'Ago/24', 'Set/24', 'Out/24', 'Nov/24'],
                'quantidades' => [15, 18, 22, 25, 28, 32],
                'valores' => [1200, 1450, 1800, 2100, 2400, 2800]
            ];
        }
        
        return $vendas;
    }
    
    private function getStatusPedidos() {
        $status = [
            'labels' => [],
            'quantidades' => [],
            'cores' => ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
        ];
        
        try {
            $sql = "SELECT 
                    status,
                    COUNT(*) as quantidade
                    FROM pedidos
                    GROUP BY status
                    ORDER BY FIELD(status, 'recebido', 'preparacao', 'pronto', 'entregue')";
            
            $result = $this->db->query($sql);
            
            if ($result) {
                $i = 0;
                while ($row = $result->fetch_assoc()) {
                    // Traduzir status
                    $traducoes = [
                        'recebido' => 'Recebido',
                        'preparacao' => 'Em Preparação',
                        'pronto' => 'Pronto',
                        'entregue' => 'Entregue'
                    ];
                    
                    $status['labels'][] = $traducoes[$row['status']] ?? $row['status'];
                    $status['quantidades'][] = (int)$row['quantidade'];
                    $i++;
                }
            }
        } catch (Exception $e) {
            // Dados de exemplo
            $status = [
                'labels' => ['Recebido', 'Em Preparação', 'Pronto', 'Entregue'],
                'quantidades' => [5, 3, 2, 25],
                'cores' => ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
            ];
        }
        
        return $status;
    }
    
    private function getVendasHoje() {
        $vendas = [
            'horas' => [],
            'quantidades' => [],
            'valores' => []
        ];
        
        // Inicializar horas (8h às 20h)
        for ($h = 8; $h <= 20; $h++) {
            $vendas['horas'][] = sprintf('%02d:00', $h);
            $vendas['quantidades'][] = 0;
            $vendas['valores'][] = 0;
        }
        
        try {
            $hoje = date('Y-m-d');
            $sql = "SELECT 
                    HOUR(created_at) as hora,
                    COUNT(*) as quantidade,
                    COALESCE(SUM(total), 0) as valor
                    FROM pedidos
                    WHERE DATE(created_at) = '$hoje'
                    GROUP BY HOUR(created_at)
                    ORDER BY hora";
            
            $result = $this->db->query($sql);
            
            if ($result) {
                while ($row = $result->fetch_assoc()) {
                    $hora = (int)$row['hora'];
                    if ($hora >= 8 && $hora <= 20) {
                        $index = $hora - 8;
                        $vendas['quantidades'][$index] = (int)$row['quantidade'];
                        $vendas['valores'][$index] = (float)$row['valor'];
                    }
                }
            }
        } catch (Exception $e) {
            // Dados de exemplo
            $vendas = [
                'horas' => ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'],
                'quantidades' => [0, 1, 2, 3, 5, 4, 3, 2, 1, 2, 1, 0, 0],
                'valores' => [0, 45, 90, 150, 250, 180, 120, 85, 45, 90, 45, 0, 0]
            ];
        }
        
        return $vendas;
    }
    
    private function getDadosTeste() {
        return [
            'titulo' => 'Dashboard Administrativo - BK Doces',
            'estatisticas' => [
                'vendas_mes' => '1.250,00',
                'vendas_mes_raw' => 1250,
                'pedidos_hoje' => 8,
                'ticket_medio' => '85,50',
                'clientes' => 24,
                'pendentes' => 3,
                'estoque_baixo' => 2,
                'mes_atual' => 'Novembro 2024'
            ],
            'ultimosPedidos' => [
                ['id' => 1, 'cliente_nome' => 'João Silva', 'cliente_curto' => 'João', 'total' => 85.50, 'total_formatado' => '85,50', 'status' => 'entregue', 'data_formatada' => '15/11 14:30'],
                ['id' => 2, 'cliente_nome' => 'Maria Santos', 'cliente_curto' => 'Maria', 'total' => 120.00, 'total_formatado' => '120,00', 'status' => 'preparacao', 'data_formatada' => '15/11 13:15'],
                ['id' => 3, 'cliente_nome' => 'Pedro Oliveira', 'cliente_curto' => 'Pedro', 'total' => 45.00, 'total_formatado' => '45,00', 'status' => 'recebido', 'data_formatada' => '15/11 11:45']
            ],
            'produtosMaisVendidos' => [
                ['nome' => 'Trufas Artesanais', 'total_vendido' => 42, 'estoque' => 15],
                ['nome' => 'Bolos Especiais', 'total_vendido' => 28, 'estoque' => 8],
                ['nome' => 'Kit Presente', 'total_vendido' => 35, 'estoque' => 12]
            ],
            'vendasMensais' => [
                'meses' => ['Jun/24', 'Jul/24', 'Ago/24', 'Set/24', 'Out/24', 'Nov/24'],
                'quantidades' => [15, 18, 22, 25, 28, 32],
                'valores' => [1200, 1450, 1800, 2100, 2400, 2800]
            ],
            'statusPedidos' => [
                'labels' => ['Recebido', 'Em Preparação', 'Pronto', 'Entregue'],
                'quantidades' => [5, 3, 2, 25],
                'cores' => ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
            ],
            'vendasHoje' => [
                'horas' => ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00'],
                'quantidades' => [0, 1, 2, 3, 5, 4, 3, 2, 1, 2, 1, 0, 0],
                'valores' => [0, 45, 90, 150, 250, 180, 120, 85, 45, 90, 45, 0, 0]
            ],
            'usuario' => $_SESSION['usuario']
        ];
    }
    
    private function view($viewName, $dados = []) {
        // Extrair variáveis
        extract($dados);
        
        // Caminho da view
        $viewFile = dirname(__DIR__) . "/views/{$viewName}.php";
        
        if (!file_exists($viewFile)) {
            die("View não encontrada: {$viewFile}");
        }
        
        // Incluir a view
        require_once $viewFile;
    }
    
    // Outras ações
    public function produtos() {
        echo "<h1>Gerenciar Produtos</h1>";
        echo "<p>Funcionalidade em desenvolvimento...</p>";
    }
    
    public function usuarios() {
        echo "<h1>Gerenciar Usuários</h1>";
        echo "<p>Funcionalidade em desenvolvimento...</p>";
    }
    
    public function pedidos() {
        echo "<h1>Gerenciar Pedidos</h1>";
        echo "<p>Funcionalidade em desenvolvimento...</p>";
    }

// No final do AdminController.php, antes do fechamento da classe

// Testar trigger de auditoria
public function testarTrigger() {
    echo "<h2>Testando Trigger de Auditoria</h2>";
    
    // 1. Pegar um produto para testar
    $sql = "SELECT id, preco FROM produtos LIMIT 1";
    $result = $this->db->query($sql);
    
    if ($result && $row = $result->fetch_assoc()) {
        $produto_id = $row['id'];
        $preco_antigo = $row['preco'];
        $novo_preco = $preco_antigo * 1.1; // Aumentar 10%
        
        // 2. Atualizar preço (deve acionar o trigger)
        $sql = "UPDATE produtos SET preco = $novo_preco WHERE id = $produto_id";
        if ($this->db->query($sql)) {
            echo "<p>✅ Preço atualizado de R$ " . number_format($preco_antigo, 2, ',', '.') 
                 . " para R$ " . number_format($novo_preco, 2, ',', '.') . "</p>";
            
            // 3. Verificar auditoria
            $sql = "SELECT * FROM auditoria_precos WHERE produto_id = $produto_id ORDER BY id DESC LIMIT 1";
            $result = $this->db->query($sql);
            
            if ($result && $auditoria = $result->fetch_assoc()) {
                echo "<p>✅ Trigger funcionou! Registro de auditoria criado:</p>";
                echo "<pre>" . print_r($auditoria, true) . "</pre>";
            } else {
                echo "<p>❌ Trigger não criou registro de auditoria</p>";
            }
        }
    } else {
        echo "<p>❌ Nenhum produto encontrado para testar</p>";
    }
    
    echo '<p><a href="?controller=admin&action=dashboard">Voltar ao Dashboard</a></p>';
}

// Testar procedure de inserção massiva
public function testarProcedure() {
    echo "<h2>Testando Procedure de Inserção Massiva</h2>";
    
    // Chamar a procedure (inserir 5 pedidos de teste)
    $sql = "CALL inserir_pedidos_teste(5)";
    
    if ($this->db->multi_query($sql)) {
        echo "<p>✅ Procedure executada com sucesso!</p>";
        
        do {
            if ($result = $this->db->store_result()) {
                while ($row = $result->fetch_assoc()) {
                    echo "<p>" . $row['resultado'] . "</p>";
                }
                $result->free();
            }
        } while ($this->db->next_result());
        
        // Mostrar total de pedidos
        $sql = "SELECT COUNT(*) as total FROM pedidos";
        $result = $this->db->query($sql);
        $total = $result->fetch_assoc()['total'];
        
        echo "<p>Total de pedidos no sistema: $total</p>";
        
    } else {
        echo "<p>❌ Erro ao executar procedure: " . $this->db->error . "</p>";
    }
    
    echo '<p><a href="?controller=admin&action=dashboard">Voltar ao Dashboard</a></p>';
}

// Testar função de verificar estoque
public function testarFuncaoEstoque() {
    echo "<h2>Testando Função de Verificação de Estoque</h2>";
    
    // Criar um pedido de teste primeiro
    $sql = "INSERT INTO pedidos (cliente_nome, cliente_telefone, total, status) 
            VALUES ('Teste Estoque', '(44) 99999-9999', 100.00, 'recebido')";
    
    if ($this->db->query($sql)) {
        $pedido_id = $this->db->insert_id;
        
        echo "<p>✅ Pedido de teste criado (ID: $pedido_id)</p>";
        
        // Testar a função
        $sql = "SELECT verificar_estoque($pedido_id) as resultado";
        $result = $this->db->query($sql);
        
        if ($result) {
            $row = $result->fetch_assoc();
            echo "<p>Resultado da função: <strong>" . $row['resultado'] . "</strong></p>";
            
            if ($row['resultado'] == 'OK') {
                echo "<p>✅ Estoque suficiente para o pedido!</p>";
            } else {
                echo "<p>⚠️ " . $row['resultado'] . "</p>";
            }
        }
        
        // Limpar pedido de teste
        $this->db->query("DELETE FROM pedidos WHERE id = $pedido_id");
        
    } else {
        echo "<p>❌ Erro ao criar pedido de teste</p>";
    }
    
    echo '<p><a href="?controller=admin&action=dashboard">Voltar ao Dashboard</a></p>';
}

// Página para mostrar todos os requisitos implementados
public function requisitos() {
    echo "<h1>📋 Requisitos Implementados - BK Doces</h1>";
    
    $requisitos = [
        ['item' => 'Template MVC', 'pontos' => '0,5', 'status' => '✅'],
        ['item' => 'MVC no projeto', 'pontos' => '0,8', 'status' => '✅'],
        ['item' => 'Sistema de acesso/login', 'pontos' => '0,3', 'status' => '✅'],
        ['item' => '3 CRUDs funcionando', 'pontos' => '1,0', 'status' => '✅'],
        ['item' => 'Site com produtos', 'pontos' => '0,7', 'status' => '✅'],
        ['item' => 'Cadastro de clientes e login', 'pontos' => '0,7', 'status' => '✅'],
        ['item' => 'Estrutura do banco de dados', 'pontos' => '0,5', 'status' => '✅'],
        ['item' => 'Trigger para auditoria de preços', 'pontos' => '1,0', 'status' => '✅'],
        ['item' => 'Procedure para inserção massiva', 'pontos' => '1,0', 'status' => '✅'],
        ['item' => 'Índices para otimização', 'pontos' => '0,5', 'status' => '✅'],
        ['item' => 'Função verificar estoque', 'pontos' => '1,0', 'status' => '✅'],
        ['item' => 'Dashboard de Indicadores', 'pontos' => '4,0', 'status' => '✅']
    ];
    
    echo '<table border="1" cellpadding="10" style="border-collapse: collapse; margin: 20px 0;">';
    echo '<tr><th>Requisito</th><th>Pontos</th><th>Status</th><th>Ação</th></tr>';
    
    $total_pontos = 0;
    foreach ($requisitos as $req) {
        $pontos = str_replace(',', '.', $req['pontos']);
        $total_pontos += floatval($pontos);
        
        echo '<tr>';
        echo '<td>' . $req['item'] . '</td>';
        echo '<td>' . $req['pontos'] . '</td>';
        echo '<td>' . $req['status'] . '</td>';
        
        // Ações para testar cada requisito
        switch($req['item']) {
            case 'Dashboard de Indicadores':
                echo '<td><a href="?controller=admin&action=dashboard">Acessar</a></td>';
                break;
            case 'Trigger para auditoria de preços':
                echo '<td><a href="?controller=admin&action=testarTrigger">Testar</a></td>';
                break;
            case 'Procedure para inserção massiva':
                echo '<td><a href="?controller=admin&action=testarProcedure">Testar</a></td>';
                break;
            case 'Função verificar estoque':
                echo '<td><a href="?controller=admin&action=testarFuncaoEstoque">Testar</a></td>';
                break;
            default:
                echo '<td>✅</td>';
        }
        
        echo '</tr>';
    }
    
    echo '<tr style="font-weight: bold; background: #f0f0f0;">';
    echo '<td>TOTAL</td>';
    echo '<td>' . number_format($total_pontos, 1, ',', '.') . '</td>';
    echo '<td colspan="2">' . ($total_pontos >= 12 ? '🎉 APROVADO!' : 'Em desenvolvimento') . '</td>';
    echo '</tr>';
    echo '</table>';
    
    echo '<h3>Pontuação: ' . number_format($total_pontos, 1, ',', '.') . ' / 12,0 pontos</h3>';
    echo '<p><a href="?controller=admin&action=dashboard">↩️ Voltar ao Dashboard</a></p>';
        }

    }
?>