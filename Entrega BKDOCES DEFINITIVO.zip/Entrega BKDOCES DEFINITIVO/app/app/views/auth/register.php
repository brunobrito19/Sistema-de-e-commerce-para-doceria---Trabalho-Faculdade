<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo ?? 'Cadastro - BK Doces'; ?></title>
    <style>
        <?php 
        // Mesmo CSS do login
        echo "
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .auth-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 450px;
            overflow: hidden;
        }
        
        .auth-header {
            background: #5A2D2D;
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .auth-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .auth-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #5A2D2D;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #FF6B8B;
        }
        
        .btn-auth {
            background: #FF6B8B;
            color: white;
            border: none;
            padding: 15px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s;
            margin-top: 10px;
        }
        
        .btn-auth:hover {
            background: #ff4d73;
        }
        
        .btn-secondary {
            background: #5A2D2D;
        }
        
        .btn-secondary:hover {
            background: #7A3D3D;
        }
        
        .auth-links {
            text-align: center;
            margin-top: 20px;
        }
        
        .auth-links a {
            color: #FF6B8B;
            text-decoration: none;
            font-weight: bold;
        }
        
        .auth-links a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .alert-error {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #c62828;
        }
        
        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #2e7d32;
        }
        
        .back-home {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-home a {
            color: #5A2D2D;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .password-strength {
            margin-top: 5px;
            font-size: 0.8rem;
            color: #666;
        }
        ";
        ?>
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-header">
            <h1>🍫 BK Doces</h1>
            <p>Crie sua Conta</p>
        </div>
        
        <div class="auth-form">
            <?php if (isset($erro)): ?>
                <div class="alert alert-error">
                    <?php echo $erro; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($sucesso)): ?>
                <div class="alert alert-success">
                    <?php echo $sucesso; ?>
                </div>
            <?php endif; ?>
            
            <h2 style="color: #5A2D2D; margin-bottom: 20px; text-align: center;">📝 Criar Nova Conta</h2>
            
            <form method="POST" action="" onsubmit="return validarCadastro()">
                <div class="form-group">
                    <label for="nome">👤 Nome Completo</label>
                    <input type="text" id="nome" name="nome" required 
                           placeholder="Seu nome completo" value="<?php echo $_POST['nome'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">📧 E-mail</label>
                    <input type="email" id="email" name="email" required 
                           placeholder="seu@email.com" value="<?php echo $_POST['email'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="senha">🔑 Senha (mínimo 6 caracteres)</label>
                    <input type="password" id="senha" name="senha" required 
                           placeholder="Crie uma senha" onkeyup="verificarForcaSenha()">
                    <div class="password-strength" id="password-strength"></div>
                </div>
                
                <div class="form-group">
                    <label for="confirmar_senha">🔁 Confirmar Senha</label>
                    <input type="password" id="confirmar_senha" name="confirmar_senha" required 
                           placeholder="Digite a senha novamente">
                </div>
                
                <button type="submit" name="register" class="btn-auth">
                    🎉 Criar Minha Conta
                </button>
            </form>
            
            <div class="auth-links">
                <p>Já tem uma conta? <a href="<?php echo BASE_URL; ?>?controller=auth&action=login">Faça login aqui</a></p>
            </div>
            
            <div class="back-home">
                <a href="<?php echo BASE_URL; ?>">
                    ← Voltar para o site
                </a>
            </div>
            
            <!-- Benefícios -->
            <div style="margin-top: 25px; padding: 15px; background: #FFF5F5; border-radius: 10px;">
                <p style="color: #5A2D2D; font-weight: bold; margin-bottom: 10px;">🎁 Benefícios de ter uma conta:</p>
                <ul style="padding-left: 20px; color: #666;">
                    <li>Faça pedidos online</li>
                    <li>Salve seus endereços</li>
                    <li>Acompanhe seus pedidos</li>
                    <li>Receba ofertas exclusivas</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script>
        function verificarForcaSenha() {
            const senha = document.getElementById('senha').value;
            const strengthDiv = document.getElementById('password-strength');
            
            if (senha.length === 0) {
                strengthDiv.innerHTML = '';
                return;
            }
            
            let strength = 0;
            let color = '#c62828';
            let text = 'Fraca';
            
            if (senha.length >= 6) strength++;
            if (/[A-Z]/.test(senha)) strength++;
            if (/[0-9]/.test(senha)) strength++;
            if (/[^A-Za-z0-9]/.test(senha)) strength++;
            
            if (strength >= 3) {
                color = '#2e7d32';
                text = 'Forte';
            } else if (strength >= 2) {
                color = '#ff9800';
                text = 'Média';
            }
            
            strengthDiv.innerHTML = `Força da senha: <strong style="color: ${color}">${text}</strong>`;
            strengthDiv.style.color = color;
        }
        
        function validarCadastro() {
            const senha = document.getElementById('senha').value;
            const confirmar = document.getElementById('confirmar_senha').value;
            
            if (senha !== confirmar) {
                alert('As senhas não coincidem!');
                return false;
            }
            
            if (senha.length < 6) {
                alert('A senha deve ter pelo menos 6 caracteres!');
                return false;
            }
            
            return true;
        }
    </script>
</body>
</html>
<?php
$content = ob_get_clean();
echo $content;
?>