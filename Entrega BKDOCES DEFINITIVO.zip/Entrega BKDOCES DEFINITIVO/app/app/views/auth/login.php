<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo ?? 'Login - BK Doces'; ?></title>
    <style>
        <?php 
        // CSS básico para auth
        echo "
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .auth-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            overflow: hidden;
        }
        
        .auth-header {
            background: #5A2D2D;
            color: white;
            padding: 30px;
            text-align: center;
        }
        
        .auth-header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        
        .auth-form {
            padding: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #5A2D2D;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: #FF6B8B;
        }
        
        .btn-auth {
            background: #FF6B8B;
            color: white;
            border: none;
            padding: 15px;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s;
            margin-top: 10px;
        }
        
        .btn-auth:hover {
            background: #ff4d73;
        }
        
        .btn-secondary {
            background: #5A2D2D;
        }
        
        .btn-secondary:hover {
            background: #7A3D3D;
        }
        
        .auth-links {
            text-align: center;
            margin-top: 20px;
        }
        
        .auth-links a {
            color: #FF6B8B;
            text-decoration: none;
            font-weight: bold;
        }
        
        .auth-links a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .alert-error {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #c62828;
        }
        
        .alert-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #2e7d32;
        }
        
        .back-home {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-home a {
            color: #5A2D2D;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        ";
        ?>
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-header">
            <h1>🍫 BK Doces</h1>
            <p>Área de Acesso</p>
        </div>
        
        <div class="auth-form">
            <?php if (isset($erro)): ?>
                <div class="alert alert-error">
                    <?php echo $erro; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_SESSION['mensagem'])): ?>
                <div class="alert alert-success">
                    <?php echo $_SESSION['mensagem']; ?>
                    <?php unset($_SESSION['mensagem']); ?>
                </div>
            <?php endif; ?>
            
            <h2 style="color: #5A2D2D; margin-bottom: 20px; text-align: center;">🔐 Faça seu Login</h2>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email">📧 E-mail</label>
                    <input type="email" id="email" name="email" required 
                           placeholder="seu@email.com" value="<?php echo $_POST['email'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="senha">🔑 Senha</label>
                    <input type="password" id="senha" name="senha" required 
                           placeholder="Sua senha">
                </div>
                
                <button type="submit" name="login" class="btn-auth">
                    🚀 Entrar na Minha Conta
                </button>
            </form>
            
            <div class="auth-links">
                <p>Não tem uma conta? <a href="<?php echo BASE_URL; ?>?controller=auth&action=register">Cadastre-se aqui</a></p>
            </div>
            
            <div class="back-home">
                <a href="<?php echo BASE_URL; ?>">
                    ← Voltar para o site
                </a>
            </div>
            
            <!-- Credenciais de teste -->
            <div style="margin-top: 25px; padding: 15px; background: #FFF5F5; border-radius: 10px; font-size: 0.9rem;">
                <p style="color: #666; margin-bottom: 5px;"><strong>👨‍🏫 Credenciais para Teste:</strong></p>
                <p><strong>Admin:</strong> admin@bkdoces.com / admin123</p>
                <p><strong>Cliente:</strong> Cadastre-se ou use qualquer e-mail/senha</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$content = ob_get_clean();
echo $content;
?>