<?php
// app/views/sobre.php - VERSÃO SIMPLIFICADA
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre - BK Doces</title>
    
    <!-- EM VEZ DE include, copie o CSS básico aqui -->
    <style>
        /* CSS Básico - mesmo do home.php */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #FFF5F5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #5A2D2D;
        }
        
        header {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            padding: 20px;
            color: white;
            text-align: center;
        }
        
        .nav-links {
            margin-top: 15px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 8px 15px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 20px;
        }
        
        main {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .carrinho-icone {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #FF6B8B;
            color: white;
            padding: 15px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <header>
        <h1>🍫 BK Doces</h1>
        <p>Nossa Doce História</p>
        
        <nav>
            <div class="nav-links">
                <a href="<?php echo BASE_URL; ?>?controller=home&action=index">🏠 Home</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=sobre">📖 Sobre</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=contato">📞 Contato</a>
        
        <?php if (isset($_SESSION['usuario'])): ?>
            <!-- Usuário LOGADO -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=logout" 
               style="background: rgba(255, 107, 139, 0.8);">
                👋 Sair (<?php echo $_SESSION['usuario']['nome']; ?>)
            </a>
        <?php else: ?>
            <!-- Usuário NÃO logado -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=login" 
               style="background: rgba(46, 125, 50, 0.8);">
                🔐 Login/Cadastro
            </a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    
    <div class="carrinho-icone" onclick="alert('Carrinho será implementado!')">
        🛒
        <div style="position: absolute; top: -5px; right: -5px; background: red; color: white; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; display: flex; align-items: center; justify-content: center;">0</div>
    </div>
    
    <main>
        <h2 style="text-align: center; color: #FF6B8B; margin-bottom: 30px;">📖 Página Sobre</h2>
        
        <div style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            <p>Esta é a página Sobre do sistema MVC.</p>
            <p>Em breve teremos conteúdo completo aqui!</p>
            
            <div style="margin-top: 20px; padding: 15px; background: #e8f5e9; border-radius: 10px;">
                <h3>✅ Sistema MVC Funcionando!</h3>
                <p>Controller: <strong>HomeController</strong></p>
                <p>Action: <strong>sobre()</strong></p>
                <p>View: <strong>sobre.php</strong></p>
            </div>
        </div>
    </main>
    
    <footer style="text-align: center; padding: 20px; margin-top: 50px; background: #5A2D2D; color: white;">
        <p>© <?php echo date('Y'); ?> BK Doces - Sistema MVC</p>
    </footer>
</body>
</html>
<?php
$content = ob_get_clean();
echo $content;
?>