<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato - BK Doces</title>
    <style>
        /* CSS Básico - mesmo do sobre.php */
        <?php 
        // Podemos incluir o CSS de forma segura
        $cssSimple = "
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #FFF5F5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: #5A2D2D;
        }
        
        header {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            padding: 20px;
            color: white;
            text-align: center;
        }
        
        .nav-links {
            margin-top: 15px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 8px 15px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 20px;
        }
        
        main {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        
        .carrinho-icone {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #FF6B8B;
            color: white;
            padding: 15px;
            border-radius: 50%;
            cursor: pointer;
            z-index: 1000;
        }
        
        /* Estilos específicos para contato */
        .contact-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        
        .contact-form {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .contact-info {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }
        
        .btn-enviar {
            background: #FF6B8B;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: bold;
            width: 100%;
        }
        
        .btn-enviar:hover {
            background: #ff4d73;
        }
        
        .contact-card {
            background: #FFF5F5;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 15px;
            border-left: 4px solid #FF6B8B;
        }
        ";
        echo $cssSimple;
        ?>
    </style>
</head>
<body>
    <header>
        <h1>🍫 BK Doces</h1>
        <p>Fale Conosco</p>
        
        <nav>
            <div class="nav-links">
                <a href="<?php echo BASE_URL; ?>?controller=home&action=index">🏠 Home</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=sobre">📖 Sobre</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=contato">📞 Contato</a>
        
        <?php if (isset($_SESSION['usuario'])): ?>
            <!-- Usuário LOGADO -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=logout" 
               style="background: rgba(255, 107, 139, 0.8);">
                👋 Sair (<?php echo $_SESSION['usuario']['nome']; ?>)
            </a>
        <?php else: ?>
            <!-- Usuário NÃO logado -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=login" 
               style="background: rgba(46, 125, 50, 0.8);">
                🔐 Login/Cadastro
            </a>
        <?php endif; ?>
            </div>
        </nav>
    </header>
    
    <div class="carrinho-icone" onclick="alert('Carrinho será implementado!')">
        🛒
        <div style="position: absolute; top: -5px; right: -5px; background: red; color: white; width: 20px; height: 20px; border-radius: 50%; font-size: 12px; display: flex; align-items: center; justify-content: center;">0</div>
    </div>
    
    <main>
        <h2 style="text-align: center; color: #FF6B8B; margin-bottom: 30px;">📞 Entre em Contato</h2>
        
        <div class="contact-container">
            <!-- Formulário de Contato -->
            <div class="contact-form">
                <h3>📝 Envie uma Mensagem</h3>
                <form action="#" method="POST" onsubmit="alert('Formulário enviado! (em desenvolvimento)'); return false;">
                    <div class="form-group">
                        <label for="nome">Nome Completo</label>
                        <input type="text" id="nome" name="nome" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="telefone">Telefone</label>
                        <input type="tel" id="telefone" name="telefone">
                    </div>
                    
                    <div class="form-group">
                        <label for="assunto">Assunto</label>
                        <select id="assunto" name="assunto" style="width: 100%; padding: 12px; border-radius: 8px;">
                            <option value="duvida">Dúvida</option>
                            <option value="pedido">Pedido Especial</option>
                            <option value="reclamacao">Reclamação</option>
                            <option value="elogio">Elogio</option>
                            <option value="outro">Outro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="mensagem">Mensagem</label>
                        <textarea id="mensagem" name="mensagem" rows="5" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn-enviar">📤 Enviar Mensagem</button>
                </form>
            </div>
            
            <!-- Informações de Contato -->
            <div class="contact-info">
                <h3>📍 Nossos Contatos</h3>
                
                <div class="contact-card">
                    <h4>👤 Kailayne</h4>
                    <p><strong>📞 Telefone:</strong> (44) 97400-2656</p>
                    <p><strong>📧 E-mail:</strong> kailayne@bkdoces.com</p>
                    <p><strong>⏰ Horário:</strong> 9h às 18h</p>
                </div>
                
                <div class="contact-card">
                    <h4>👤 Bruno</h4>
                    <p><strong>📞 Telefone:</strong> (44) 99726-9992</p>
                    <p><strong>📧 E-mail:</strong> bruno@bkdoces.com</p>
                    <p><strong>⏰ Horário:</strong> 9h às 18h</p>
                </div>
                
                <div class="contact-card">
                    <h4>🏢 Endereço</h4>
                    <p><strong>📍 Localização:</strong> Av. Armelindo Trombini - Jardim Flora II</p>
                    <p><strong>🌆 Cidade:</strong> Campo Mourão - PR</p>
                    <p><strong>⏰ Horário de Funcionamento:</strong> Segunda a Sábado, 9h às 18h</p>
                </div>
                
                <div class="contact-card" style="background: #e8f5e9;">
                    <h4>📱 Redes Sociais</h4>
                    <p><strong>Instagram:</strong> @bkdocesoficial</p>
                    <p><strong>Facebook:</strong> /bkdoces</p>
                    <p><strong>WhatsApp:</strong> (44) 97400-2656</p>
                </div>
            </div>
        </div>
        
        <!-- Mapa (placeholder) -->
        <div style="margin-top: 50px; text-align: center;">
            <h3 style="color: #FF6B8B; margin-bottom: 20px;">🗺️ Nossa Localização</h3>
            <div style="background: #f8f8f8; padding: 40px; border-radius: 15px;">
                <p style="font-size: 1.2rem; color: #FF6B8B;">📍 Mapa interativo aqui</p>
                <p>(Integração com Google Maps em desenvolvimento)</p>
                <div style="margin-top: 20px; padding: 20px; background: white; border-radius: 10px;">
                    <p><strong>Endereço completo:</strong></p>
                    <p>Av. Armelindo Trombini - Jardim Flora II, Campo Mourão - PR</p>
                </div>
            </div>
        </div>
    </main>
    
    <footer style="text-align: center; padding: 20px; margin-top: 50px; background: #5A2D2D; color: white;">
        <p><span style="font-size: 1.2rem;">🍫</span> © <?php echo date('Y'); ?> BK Doces - Sistema MVC <span style="font-size: 1.2rem;">🍬</span></p>
        <p>Campo Mourão - PR | Entre em contato conosco!</p>
    </footer>
</body>
</html>
<?php
$content = ob_get_clean();
echo $content;
?>