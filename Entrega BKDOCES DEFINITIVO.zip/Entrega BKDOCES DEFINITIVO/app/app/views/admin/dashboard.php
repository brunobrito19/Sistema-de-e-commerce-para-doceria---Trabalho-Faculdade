<?php
// app/views/admin/dashboard.php
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo; ?></title>
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        :root {
            --primary: #FF6B8B;
            --secondary: #FF8E53;
            --success: #28a745;
            --info: #17a2b8;
            --warning: #ffc107;
            --danger: #dc3545;
            --light: #f8f9fa;
            --dark: #343a40;
            --card-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .dashboard-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        /* Header */
        .dashboard-header {
            background: linear-gradient(135deg, #2c3e50 0%, #4a6491 100%);
            color: white;
            padding: 25px 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: var(--card-shadow);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header-title h1 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }
        
        .header-title p {
            color: #aaa;
            font-size: 0.9rem;
        }
        
        .header-user {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-info {
            text-align: right;
        }
        
        .user-info strong {
            display: block;
            font-size: 1.1rem;
        }
        
        .user-info small {
            color: #aaa;
            font-size: 0.85rem;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
            display: flex;
            align-items: center;
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
            border-left: 5px solid;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
        }
        
        .stat-card.sales { border-left-color: var(--primary); }
        .stat-card.orders { border-left-color: var(--info); }
        .stat-card.customers { border-left-color: var(--success); }
        .stat-card.pending { border-left-color: var(--warning); }
        .stat-card.ticket { border-left-color: #6f42c1; }
        .stat-card.stock { border-left-color: var(--danger); }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 1.5rem;
            color: white;
        }
        
        .stat-icon.sales { background: linear-gradient(135deg, var(--primary), var(--secondary)); }
        .stat-icon.orders { background: linear-gradient(135deg, var(--info), #5B86E5); }
        .stat-icon.customers { background: linear-gradient(135deg, var(--success), #38ef7d); }
        .stat-icon.pending { background: linear-gradient(135deg, var(--warning), #ff9966); }
        .stat-icon.ticket { background: linear-gradient(135deg, #6f42c1, #d04ed6); }
        .stat-icon.stock { background: linear-gradient(135deg, var(--danger), #ff6b6b); }
        
        .stat-content h3 {
            font-size: 0.9rem;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
        }
        
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 5px;
        }
        
        .stat-description {
            font-size: 0.85rem;
            color: #888;
        }
        
        /* Charts Section */
        .charts-section {
            margin-bottom: 30px;
        }
        
        .section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title h2 {
            color: #2c3e50;
            font-size: 1.4rem;
        }
        
        .time-filter {
            display: flex;
            gap: 10px;
        }
        
        .time-filter button {
            padding: 8px 15px;
            border: 1px solid #ddd;
            background: white;
            border-radius: 20px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s;
        }
        
        .time-filter button.active {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }
        
        .charts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 30px;
        }
        
        .chart-container {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
        }
        
        .chart-container h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .chart-container h3 i {
            color: var(--primary);
        }
        
        /* Tables Grid */
        .tables-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .table-container {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: var(--card-shadow);
        }
        
        .table-container h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .table-container h3 a {
            font-size: 0.85rem;
            color: var(--primary);
            text-decoration: none;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            text-align: left;
            padding: 12px 15px;
            border-bottom: 2px solid #f0f0f0;
            color: #666;
            font-weight: 600;
            font-size: 0.85rem;
            text-transform: uppercase;
        }
        
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 0.9rem;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            display: inline-block;
            text-align: center;
            min-width: 80px;
        }
        
        .status-recebido { background-color: #fff3cd; color: #856404; }
        .status-preparacao { background-color: #d1ecf1; color: #0c5460; }
        .status-pronto { background-color: #cce5ff; color: #004085; }
        .status-entregue { background-color: #d4edda; color: #155724; }
        
        /* Footer */
        .dashboard-footer {
            text-align: center;
            padding: 20px;
            color: #666;
            font-size: 0.85rem;
            border-top: 1px solid #eee;
            margin-top: 30px;
        }
        
        /* Responsividade */
        @media (max-width: 1200px) {
            .charts-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .dashboard-header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
            
            .header-user {
                flex-direction: column;
            }
            
            .user-info {
                text-align: center;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
            
            .tables-grid {
                grid-template-columns: 1fr;
            }
            
            .charts-grid {
                gap: 20px;
            }
            
            .chart-container {
                padding: 15px;
            }
        }
        
        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .fade-in {
            animation: fadeIn 0.5s ease-out;
        }
        
        /* Loader */
        .loader {
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 20px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Header -->
        <div class="dashboard-header fade-in">
            <div class="header-title">
                <h1>📊 Dashboard Administrativo</h1>
                <p>BK Doces - Painel de controle e análise de dados</p>
            </div>
            <div class="header-user">
                <div class="user-info">
                    <strong><?php echo $usuario['nome']; ?></strong>
                    <small><?php echo $usuario['email']; ?></small>
                    <small>Administrador</small>
                </div>
                <div class="user-avatar">
                    <?php echo strtoupper(substr($usuario['nome'], 0, 1)); ?>
                </div>
            </div>
        </div>
        
        <!-- Stats Cards -->
        <div class="stats-grid fade-in">
            <div class="stat-card sales" onclick="location.href='?controller=admin&action=pedidos'">
                <div class="stat-icon sales">
                    <i class="bi bi-currency-dollar"></i>
                </div>
                <div class="stat-content">
                    <h3>Vendas do Mês</h3>
                    <div class="stat-value">R$ <?php echo $estatisticas['vendas_mes']; ?></div>
                    <div class="stat-description"><?php echo $estatisticas['mes_atual']; ?></div>
                </div>
            </div>
            
            <div class="stat-card orders" onclick="location.href='?controller=admin&action=pedidos'">
                <div class="stat-icon orders">
                    <i class="bi bi-cart"></i>
                </div>
                <div class="stat-content">
                    <h3>Pedidos Hoje</h3>
                    <div class="stat-value"><?php echo $estatisticas['pedidos_hoje']; ?></div>
                    <div class="stat-description"><?php echo date('d/m/Y'); ?></div>
                </div>
            </div>
            
            <div class="stat-card customers" onclick="location.href='?controller=admin&action=usuarios'">
                <div class="stat-icon customers">
                    <i class="bi bi-people"></i>
                </div>
                <div class="stat-content">
                    <h3>Clientes</h3>
                    <div class="stat-value"><?php echo $estatisticas['clientes']; ?></div>
                    <div class="stat-description">Clientes ativos</div>
                </div>
            </div>
            
            <div class="stat-card pending" onclick="location.href='?controller=admin&action=pedidos'">
                <div class="stat-icon pending">
                    <i class="bi bi-clock"></i>
                </div>
                <div class="stat-content">
                    <h3>Pedidos Pendentes</h3>
                    <div class="stat-value"><?php echo $estatisticas['pendentes']; ?></div>
                    <div class="stat-description">Aguardando processamento</div>
                </div>
            </div>
            
            <div class="stat-card ticket">
                <div class="stat-icon ticket">
                    <i class="bi bi-receipt"></i>
                </div>
                <div class="stat-content">
                    <h3>Ticket Médio</h3>
                    <div class="stat-value">R$ <?php echo $estatisticas['ticket_medio']; ?></div>
                    <div class="stat-description">Valor médio por pedido</div>
                </div>
            </div>
            
            <div class="stat-card stock" onclick="location.href='?controller=admin&action=produtos'">
                <div class="stat-icon stock">
                    <i class="bi bi-exclamation-triangle"></i>
                </div>
                <div class="stat-content">
                    <h3>Estoque Baixo</h3>
                    <div class="stat-value"><?php echo $estatisticas['estoque_baixo']; ?></div>
                    <div class="stat-description">Produtos para repor</div>
                </div>
            </div>
        </div>
        
        <!-- Charts Section -->
        <div class="charts-section fade-in">
            <div class="section-title">
                <h2><i class="bi bi-graph-up"></i> Análise de Vendas</h2>
                <div class="time-filter">
                    <button class="active" onclick="filterData('month')">Mensal</button>
                    <button onclick="filterData('week')">Semanal</button>
                    <button onclick="filterData('today')">Hoje</button>
                </div>
            </div>
            
            <div class="charts-grid">
                <!-- Gráfico de Vendas Mensais -->
                <div class="chart-container">
                    <h3><i class="bi bi-bar-chart"></i> Vendas Mensais (Últimos 6 Meses)</h3>
                    <canvas id="vendasChart"></canvas>
                </div>
                
                <!-- Gráfico de Status dos Pedidos -->
                <div class="chart-container">
                    <h3><i class="bi bi-pie-chart"></i> Distribuição por Status</h3>
                    <canvas id="statusChart"></canvas>
                </div>
                
                <!-- Gráfico de Vendas por Hora (Hoje) -->
                <div class="chart-container" style="grid-column: span 2;">
                    <h3><i class="bi bi-clock-history"></i> Vendas por Hora (Hoje)</h3>
                    <canvas id="vendasHojeChart"></canvas>
                </div>
            </div>
        </div>
        
        <!-- Tables Section -->
        <div class="tables-grid fade-in">
            <!-- Últimos Pedidos -->
            <div class="table-container">
                <h3>
                    <span><i class="bi bi-cart-check"></i> Últimos Pedidos</span>
                    <a href="?controller=admin&action=pedidos">Ver todos →</a>
                </h3>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>#ID</th>
                                <th>Cliente</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ultimosPedidos as $pedido): ?>
                            <tr onclick="location.href='?controller=admin&action=pedidos'">
                                <td>#<?php echo str_pad($pedido['id'], 4, '0', STR_PAD_LEFT); ?></td>
                                <td><?php echo $pedido['cliente_curto']; ?></td>
                                <td>R$ <?php echo $pedido['total_formatado']; ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $pedido['status']; ?>">
                                        <?php echo ucfirst($pedido['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $pedido['data_formatada']; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Produtos Mais Vendidos -->
            <div class="table-container">
                <h3>
                    <span><i class="bi bi-star"></i> Produtos Mais Vendidos</span>
                    <a href="?controller=admin&action=produtos">Ver todos →</a>
                </h3>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Vendas</th>
                                <th>Estoque</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($produtosMaisVendidos as $produto): ?>
                            <tr onclick="location.href='?controller=admin&action=produtos'">
                                <td><?php echo $produto['nome']; ?></td>
                                <td><?php echo $produto['total_vendido'] ?? $produto['vendas']; ?></td>
                                <td>
                                    <?php 
                                    $estoque = $produto['estoque'] ?? 0;
                                    if ($estoque < 10): ?>
                                        <span style="color: #dc3545; font-weight: bold;">
                                            <?php echo $estoque; ?> ⚠️
                                        </span>
                                    <?php else: ?>
                                        <span style="color: #28a745;">
                                            <?php echo $estoque; ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="dashboard-footer fade-in">
            <p>BK Doces © <?php echo date('Y'); ?> - Sistema Administrativo</p>
            <p>Última atualização: <?php echo date('d/m/Y H:i:s'); ?></p>
            <p style="margin-top: 10px;">
                <button onclick="atualizarDashboard()" style="padding: 8px 15px; background: var(--primary); color: white; border: none; border-radius: 5px; cursor: pointer;">
                    <i class="bi bi-arrow-clockwise"></i> Atualizar Dados
                </button>
            </p>
        </div>
    </div>
    
    <!-- JavaScript -->
    <script>
        // Dados PHP para JavaScript
        const vendasMensais = <?php echo json_encode($vendasMensais); ?>;
        const statusPedidos = <?php echo json_encode($statusPedidos); ?>;
        const vendasHoje = <?php echo json_encode($vendasHoje); ?>;
        
        // Inicializar gráficos quando a página carregar
        document.addEventListener('DOMContentLoaded', function() {
            initVendasChart();
            initStatusChart();
            initVendasHojeChart();
            
            // Atualizar a cada 30 segundos
            setInterval(atualizarMetricas, 30000);
        });
        
        // Gráfico de Vendas Mensais
        function initVendasChart() {
            const ctx = document.getElementById('vendasChart').getContext('2d');
            window.vendasChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: vendasMensais.meses,
                    datasets: [{
                        label: 'Valor Total (R$)',
                        data: vendasMensais.valores,
                        borderColor: '#FF6B8B',
                        backgroundColor: 'rgba(255, 107, 139, 0.1)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4
                    }, {
                        label: 'Quantidade de Pedidos',
                        data: vendasMensais.quantidades,
                        borderColor: '#36A2EB',
                        backgroundColor: 'rgba(54, 162, 235, 0.1)',
                        borderWidth: 2,
                        fill: false,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    if (context.datasetIndex === 0) {
                                        return `R$ ${context.parsed.y.toFixed(2)}`;
                                    }
                                    return `${context.parsed.y} pedidos`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    if (this.scale.id === 'y') {
                                        return 'R$ ' + value.toFixed(0);
                                    }
                                    return value;
                                }
                            }
                        }
                    }
                }
            });
        }
        
        // Gráfico de Status (Pizza)
        function initStatusChart() {
            const ctx = document.getElementById('statusChart').getContext('2d');
            window.statusChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: statusPedidos.labels,
                    datasets: [{
                        data: statusPedidos.quantidades,
                        backgroundColor: statusPedidos.cores,
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.parsed || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${value} pedidos (${percentage}%)`;
                                }
                            }
                        }
                    }
                }
            });
        }
        
        // Gráfico de Vendas por Hora (Hoje)
        function initVendasHojeChart() {
            const ctx = document.getElementById('vendasHojeChart').getContext('2d');
            window.vendasHojeChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: vendasHoje.horas,
                    datasets: [{
                        label: 'Quantidade de Pedidos',
                        data: vendasHoje.quantidades,
                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        yAxisID: 'y'
                    }, {
                        label: 'Valor Total (R$)',
                        data: vendasHoje.valores,
                        backgroundColor: 'rgba(255, 107, 139, 0.7)',
                        borderColor: 'rgba(255, 107, 139, 1)',
                        borderWidth: 1,
                        type: 'line',
                        yAxisID: 'y1'
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            type: 'linear',
                            display: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Quantidade de Pedidos'
                            }
                        },
                        y1: {
                            type: 'linear',
                            display: true,
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Valor (R$)'
                            },
                            grid: {
                                drawOnChartArea: false
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    if (context.datasetIndex === 0) {
                                        return `${context.parsed.y} pedidos`;
                                    } else {
                                        return `R$ ${context.parsed.y.toFixed(2)}`;
                                    }
                                }
                            }
                        }
                    }
                }
            });
        }
        
        // Função para atualizar métricas via AJAX
        function atualizarMetricas() {
            fetch('?controller=admin&action=api&tipo=atualizar-metricas')
                .then(response => response.json())
                .then(data => {
                    // Atualizar cards
                    document.querySelector('.stat-card.sales .stat-value').textContent = 
                        'R$ ' + parseFloat(data.vendas_mes_raw).toLocaleString('pt-BR', {minimumFractionDigits: 2});
                    
                    document.querySelector('.stat-card.orders .stat-value').textContent = 
                        data.pedidos_hoje;
                    
                    document.querySelector('.stat-card.customers .stat-value').textContent = 
                        data.clientes;
                    
                    document.querySelector('.stat-card.pending .stat-value').textContent = 
                        data.pendentes;
                    
                    document.querySelector('.stat-card.ticket .stat-value').textContent = 
                        'R$ ' + parseFloat(data.ticket_medio.replace(',', '.')).toLocaleString('pt-BR', {minimumFractionDigits: 2});
                    
                    document.querySelector('.stat-card.stock .stat-value').textContent = 
                        data.estoque_baixo;
                    
                    // Atualizar hora
                    document.querySelector('.dashboard-footer p:nth-child(2)').textContent = 
                        `Última atualização: ${new Date().toLocaleString('pt-BR')}`;
                })
                .catch(error => console.error('Erro ao atualizar:', error));
        }
        
        // Função manual para atualizar
        function atualizarDashboard() {
            atualizarMetricas();
            
            // Adicionar efeito visual
            const btn = event.target.closest('button');
            btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Atualizando...';
            btn.disabled = true;
            
            setTimeout(() => {
                btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Atualizado!';
                setTimeout(() => {
                    btn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Atualizar Dados';
                    btn.disabled = false;
                }, 1000);
            }, 1000);
        }
        
        // Filtro de período (simulado)
        function filterData(period) {
            const buttons = document.querySelectorAll('.time-filter button');
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            // Aqui você implementaria a lógica para filtrar os dados
            // Por enquanto, apenas mostra mensagem
            console.log(`Filtrar por: ${period}`);
        }
    </script>
</body>
</html>