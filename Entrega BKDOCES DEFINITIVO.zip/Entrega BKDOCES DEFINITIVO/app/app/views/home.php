<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo ?? 'BK Doces'; ?></title>
    <style>
        /* Estilos Gerais */
        @import url('https://fonts.googleapis.com/css2?family=Pacifico&family=Quicksand:wght@400;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background-color: #FFF5F5;
            font-family: 'Quicksand', sans-serif;
            color: #5A2D2D;
            overflow-x: hidden;
        }
        
        /* Header */
        header {
            background: linear-gradient(135deg, #FF6B8B 0%, #FF8E53 100%);
            padding: 20px 0;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .logo h1 {
            font-family: 'Pacifico', cursive;
            color: white;
            font-size: 2.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        nav {
            display: flex;
            align-items: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .nav-links {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        
        .nav-links a:hover {
            background-color: rgba(255,255,255,0.2);
            transform: translateY(-2px);
        }
        
        .search-bar {
            display: flex;
            gap: 10px;
        }
        
        .search-bar input {
            padding: 10px 15px;
            border: none;
            border-radius: 25px;
            outline: none;
            width: 200px;
        }
        
        .search-bar button {
            padding: 10px 20px;
            background-color: #5A2D2D;
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .search-bar button:hover {
            background-color: #7A3D3D;
        }
        
        /* Main Content */
        main {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 20px;
            min-height: 70vh;
        }
        
        .section {
            display: none;
            padding: 40px 0;
        }
        
        .section.active {
            display: block;
            animation: fadeIn 0.5s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        h2 {
            font-family: 'Pacifico', cursive;
            color: #FF6B8B;
            font-size: 2.5rem;
            text-align: center;
            margin-bottom: 20px;
        }
        
        p {
            line-height: 1.6;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        
        .candy-decoration {
            text-align: center;
            font-size: 2rem;
            margin: 30px 0;
            animation: bounce 2s infinite;
        }
        
        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        
        .product-card:hover {
            transform: translateY(-10px);
        }
        
        .product-image {
            height: 200px;
            background-size: cover;
            background-position: center;
        }
        
        .product-info {
            padding: 20px;
        }
        
        .product-info h3 {
            color: #5A2D2D;
            margin-bottom: 10px;
        }
        
        .price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #FF6B8B;
            margin-top: 15px;
        }
        
        /* Contact Info */
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin: 40px 0;
        }
        
        .contact-card {
            background: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        
        .contact-card h3 {
            color: #FF6B8B;
            margin-bottom: 15px;
        }
        
        /* Floating Candies */
        .floating-candies {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            overflow: hidden;
        }
        
        .candy {
            position: absolute;
            font-size: 2rem;
            opacity: 0.3;
            animation: float linear infinite;
        }
        
        @keyframes float {
            from { transform: translateY(100vh) rotate(0deg); }
            to { transform: translateY(-100px) rotate(360deg); }
        }
        
        /* Footer */
        footer {
            background: linear-gradient(135deg, #5A2D2D 0%, #7A3D3D 100%);
            color: white;
            text-align: center;
            padding: 30px 20px;
            margin-top: 60px;
        }
        
        .candy-icon {
            font-size: 1.5rem;
            animation: spin 3s infinite;
        }
        
        @keyframes spin {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(20deg); }
        }
        
        /* Responsividade */
        @media (max-width: 768px) {
            .header-container {
                flex-direction: column;
                gap: 20px;
            }
            
            .nav-links {
                justify-content: center;
            }
            
            .search-bar {
                width: 100%;
                justify-content: center;
            }
            
            .search-bar input {
                width: 100%;
            }
            
            h2 {
                font-size: 2rem;
            }
        /* ===== CORREÇÕES PARA O MVC ===== */

/* Garantir que as imagens dos produtos carreguem */
.product-image {
    height: 200px;
    width: 100%;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
}

/* Corrigir o grid de produtos */
.product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 30px;
    margin: 40px 0;
    width: 100%;
}

/* Corrigir container principal */
main {
    max-width: 1200px;
    margin: 40px auto;
    padding: 0 20px;
    min-height: 70vh;
    width: 100%;
}

/* Corrigir header container */
.header-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    width: 100%;
}

/* Menu de navegação MVC */
.nav-links a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    padding: 10px 15px;
    border-radius: 25px;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.1);
}

.nav-links a:hover {
    background-color: rgba(255,255,255,0.3);
    transform: translateY(-2px);
}

/* Botão de compra */
.btn-comprar {
    display: inline-block;
    background: #FF6B8B;
    color: white;
    padding: 12px 25px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: bold;
    margin-top: 15px;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
    text-align: center;
    width: 100%;
}

.btn-comprar:hover {
    background: #ff4d73;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(255, 107, 139, 0.3);
}  

/* ===== CARRINHO ===== */
.carrinho-icone {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #FF6B8B;
    color: white;
    padding: 15px;
    border-radius: 50%;
    cursor: pointer;
    z-index: 1000;
    box-shadow: 0 4px 15px rgba(255, 107, 139, 0.3);
    transition: transform 0.3s ease;
    font-size: 1.2rem;
}

.carrinho-icone:hover {
    transform: scale(1.1);
}

.carrinho-contador {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ff4757;
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

/* Barra de pesquisa */
.search-bar {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin: 20px 0;
}

.search-bar input {
    padding: 10px 15px;
    border: none;
    border-radius: 25px;
    outline: none;
    width: 300px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.search-bar button {
    padding: 10px 20px;
    background-color: #5A2D2D;
    color: white;
    border: none;
    border-radius: 25px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.search-bar button:hover {
    background-color: #7A3D3D;
}
        }

/* ===== CARRINHO ===== */
.carrinho-icone {
    position: fixed;
    top: 20px;
    right: 20px;
    background: #FF6B8B;
    color: white;
    padding: 15px;
    border-radius: 50%;
    cursor: pointer;
    z-index: 1000;
    box-shadow: 0 4px 15px rgba(255, 107, 139, 0.3);
    transition: transform 0.3s ease;
    font-size: 1.2rem;
}

.carrinho-icone:hover {
    transform: scale(1.1);
}

.carrinho-contador {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #ff4757;
    color: white;
    border-radius: 50%;
    width: 20px;
    height: 20px;
    font-size: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

/* Barra de pesquisa */
.search-bar {
    display: flex;
    gap: 10px;
    justify-content: center;
    margin: 20px 0;
}

.search-bar input {
    padding: 10px 15px;
    border: none;
    border-radius: 25px;
    outline: none;
    width: 300px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.search-bar button {
    padding: 10px 20px;
    background-color: #5A2D2D;
    color: white;
    border: none;
    border-radius: 25px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.search-bar button:hover {
    background-color: #7A3D3D;
}
</style>

    </style>
</head>
<body>
        <header>

        <?php if (isset($_SESSION['usuario'])): ?>
<div style="background: #e8f5e9; padding: 15px; border-radius: 10px; margin: 15px 0; text-align: center;">
    <h3>👋 Olá, <?php echo $_SESSION['usuario']['nome']; ?>!</h3>
    <p>Bem-vindo(a) de volta à BK Doces!</p>
    <p style="font-size: 0.9rem; color: #666;">
        Email: <?php echo $_SESSION['usuario']['email']; ?> | 
        Tipo: <?php echo $_SESSION['usuario']['tipo'] == 'admin' ? 'Administrador' : 'Cliente'; ?>
    </p>
</div>
<?php endif; ?>


        <h1>🍫 BK Doces</h1>
        <p>Doces Artesanais Premium - Sistema MVC</p>
        
        <nav>
            <div class="nav-links">
               <a href="<?php echo BASE_URL; ?>?controller=home&action=index">🏠 Home</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=sobre">📖 Sobre</a>
        <a href="<?php echo BASE_URL; ?>?controller=home&action=contato">📞 Contato</a>
        
        <?php if (isset($_SESSION['usuario'])): ?>
            <!-- Usuário LOGADO -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=logout" 
               style="background: rgba(255, 107, 139, 0.8);">
                👋 Sair (<?php echo $_SESSION['usuario']['nome']; ?>)
            </a>
        <?php else: ?>
            <!-- Usuário NÃO logado -->
            <a href="<?php echo BASE_URL; ?>?controller=auth&action=login" 
               style="background: rgba(46, 125, 50, 0.8);">
                🔐 Login/Cadastro
            </a>
                <?php endif; ?>
            </div>
        </nav>
    </header>
    
    <!-- Mensagens do sistema -->
    <?php if (isset($mensagem)): ?>
        <div class="mensagem">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>
    
    <!-- ÁREA DE DEBUG - REMOVER DEPOIS -->
    <div style="background: #fff3cd; padding: 15px; margin: 15px; border-radius: 10px; border-left: 5px solid #ffc107;">
        <h3>🔍 DEBUG - Informações do Sistema:</h3>
        <p><strong>Produtos encontrados:</strong> <?php echo count($produtos ?? []); ?></p>
        <p><strong>BASE_URL:</strong> <?php echo BASE_URL; ?></p>
        <?php if (isset($erro)): ?>
            <p style="color: red;"><strong>Erro:</strong> <?php echo $erro; ?></p>
        <?php endif; ?>
    </div>
    
       <main>
        <!-- Barra de pesquisa -->
        <div style="text-align: center; margin: 20px 0;">
            <div class="search-bar" style="display: inline-flex;">
                <input type="text" placeholder="Pesquisar doces...">
                <button>Buscar</button>
            </div>
        </div>
        <h2 style="text-align: center; color: #FF6B8B; margin-bottom: 30px;">
            🍫 Nossas Delícias em Destaque
        </h2>
        
        <?php if (empty($produtos)): ?>
            <div style="text-align: center; padding: 50px; background: #f8f9fa; border-radius: 15px; margin: 20px;">
                <div style="font-size: 4rem; margin-bottom: 20px;">😟</div>
                <h3>Nenhum produto encontrado</h3>
                <p>Verifique sua conexão com o banco de dados.</p>
                <p style="color: #666; font-size: 0.9rem; margin-top: 20px;">
                    Dica: Execute no phpMyAdmin:<br>
                    <code>SELECT * FROM produtos WHERE destaque = 1;</code>
                </p>
            </div>
        <?php else: ?>
            <div class="product-grid">
                <?php foreach ($produtos as $produto): ?>
                <div class="product-card">
                    <div class="product-image" 
                         style="background-image: url('<?php echo htmlspecialchars($produto['imagem']); ?>');">
                    </div>
                    <div class="product-info">
                        <h3><?php echo htmlspecialchars($produto['nome']); ?></h3>
                        <p><?php echo htmlspecialchars(substr($produto['descricao'], 0, 100)) . '...'; ?></p>
                        <div class="price">R$ <?php echo $produto['preco_formatado']; ?></div>
                        <a href="<?php echo BASE_URL; ?>?controller=carrinho&action=add&id=<?php echo $produto['id']; ?>" 
                           class="btn-comprar">
                            🛒 Adicionar ao Carrinho
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div style="text-align: center; margin-top: 50px; padding: 25px; background: linear-gradient(135deg, #e8f5e9, #c8e6c9); border-radius: 15px;">
                <h3>🎉 Sistema MVC Funcionando!</h3>
                <p><strong><?php echo count($produtos); ?> produtos</strong> carregados do banco de dados.</p>
                <p style="color: #666; margin-top: 10px;">✅ Controller → Model → View → Banco de Dados</p>
            </div>
        <?php endif; ?>
    </main>
    
    <footer>
        <p>© <?php echo date('Y'); ?> BK Doces - Desenvolvido com PHP MVC</p>
        <p>Centro Universitário Integrado de Campo Mourão</p>
    </footer>

<!-- Ícone do Carrinho -->
<div class="carrinho-icone" onclick="alert('Carrinho será implementado!')">
    🛒
    <div class="carrinho-contador">0</div>
</div>

<!-- Barra de pesquisa (do sistema antigo) -->
<div style="text-align: center; margin: 20px 0;">
    <div class="search-bar" style="display: inline-flex;">
        <input type="text" placeholder="Pesquisar doces...">
        <button>Buscar</button>

        </div>
</div>
</body>
</html>