<?php
// public/index.php - LINHAS INICIAIS
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// public/index.php - PONTO DE ENTRADA DO SISTEMA MVC

// Iniciar sessão
session_start();

// Configurar timezone
date_default_timezone_set('America/Sao_Paulo');

// Definir constantes importantes
define('BASE_URL', 'http://localhost:8080/bkdoces-mvc/public/');
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');

// Incluir configuração do banco de dados
require_once APP_PATH . '/config/database.php';

// Função para carregar classes MANUALMENTE (mais confiável)
function carregarClasse($className) {
    $caminhos = [
        APP_PATH . '/controllers/' . $className . '.php',
        APP_PATH . '/models/' . $className . '.php',
        APP_PATH . '/config/' . $className . '.php'
    ];
    
    foreach ($caminhos as $caminho) {
        if (file_exists($caminho)) {
            require_once $caminho;
            return true;
        }
    }
    
    return false;
}

// Registrar autoload
spl_autoload_register('carregarClasse');

// Sistema de roteamento simples
$controller = $_GET['controller'] ?? 'home';
$action = $_GET['action'] ?? 'index';

// Mapeamento de controllers
$controllers = [
    'home' => 'HomeController',
    'produtos' => 'ProdutoController',
    'carrinho' => 'CarrinhoController',
    'auth' => 'AuthController',
    'admin' => 'AdminController',
];

// Processar a requisição
try {
    if (array_key_exists($controller, $controllers)) {
        $controllerName = $controllers[$controller];
        
        // Verificar se a classe pode ser carregada
        if (!class_exists($controllerName)) {
            throw new Exception("Controller '{$controllerName}' não encontrado!<br>
                                Verifique se o arquivo existe em: " . APP_PATH . "/controllers/{$controllerName}.php");
        }
        
        // Instanciar o controller
        $controllerInstance = new $controllerName();
        
        // Verificar se a ação existe
        if (!method_exists($controllerInstance, $action)) {
            throw new Exception("Ação '{$action}' não encontrada no controller '{$controllerName}'!");
        }
        
        // Executar a ação
        $controllerInstance->$action();
        
    } else {
        throw new Exception("Controller '{$controller}' não encontrado!");
    }
    
} catch (Exception $e) {
    // Página de erro detalhada
    echo "<h1>🚨 Erro no Sistema MVC</h1>";
    echo "<h3>" . $e->getMessage() . "</h3>";
    echo "<hr>";
    echo "<h4>Informações de Depuração:</h4>";
    echo "<p><strong>Controller solicitado:</strong> " . ($controller ?? 'null') . "</p>";
    echo "<p><strong>Ação solicitada:</strong> " . ($action ?? 'null') . "</p>";
    echo "<p><strong>APP_PATH:</strong> " . APP_PATH . "</p>";
    echo "<p><strong>Caminho esperado do Controller:</strong> " . APP_PATH . "/controllers/" . ($controllers[$controller] ?? '?') . ".php</p>";
    
    // Verificar se arquivo existe
    $caminhoArquivo = APP_PATH . "/controllers/" . ($controllers[$controller] ?? '') . ".php";
    echo "<p><strong>Arquivo existe?</strong> " . (file_exists($caminhoArquivo) ? '✅ SIM' : '❌ NÃO') . "</p>";
    
    if (file_exists($caminhoArquivo)) {
        echo "<p><strong>Tamanho do arquivo:</strong> " . filesize($caminhoArquivo) . " bytes</p>";
    }
    
    echo "<hr>";
    echo "<p><a href='" . BASE_URL . "'>↩️ Voltar para Home</a></p>";
}
?>