# 🍫 BK Doces - Sistema E-commerce MVC

## 📋 Descrição
Sistema de e-commerce desenvolvido em PHP com padrão MVC para a doceria BK Doces.

## 🚀 Tecnologias
- PHP 8.2
- MySQL
- HTML5/CSS3/JavaScript
- Padrão MVC

## 📁 Estrutura do Projeto ```

bkdoces-mvc/
├── app/ # Lógica da aplicação
│ ├── controllers/ # Controladores
│ ├── models/ # Modelos (banco de dados)
│ ├── views/ # Views (templates)
│ └── config/ # Configurações
├── public/ # Arquivos públicos (acessíveis na web)
└── README.md # Esta documentação


## 🔧 Instalação
1. Clone o repositório na pasta `htdocs` do XAMPP
2. Importe o banco `produtos.sql`
3. Acesse: `http://localhost:8080/bkdoces-mvc/public/`
```
## 👤 Credenciais de Teste
- Admin: admin@bkdoces.com / admin123
- MySQL: root / (senha vazia)

## 📞 Contato
Desenvolvido por Bruno Brito de Carvalho - Centro Universitário Integrado de Campo Mourão